import { useState, useEffect } from 'react';
import type { Theme } from '@/lib/types';

export function useTheme() {
  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof window !== 'undefined') {
      return (localStorage.getItem('theme') as Theme) || 'light';
    }
    return 'light';
  });

  useEffect(() => {
    const body = document.body;
    
    // Remove all existing theme classes
    body.classList.remove('theme-light', 'theme-dark', 'theme-custom', 'theme-hyland');
    
    // Add the new theme class
    body.classList.add(`theme-${theme}`);
    
    // Save to localStorage
    localStorage.setItem('theme', theme);
  }, [theme]);

  // Initialize theme on first render
  useEffect(() => {
    const body = document.body;
    if (!body.classList.contains('theme-light') && 
        !body.classList.contains('theme-dark') && 
        !body.classList.contains('theme-custom') && 
        !body.classList.contains('theme-hyland')) {
      body.classList.add(`theme-${theme}`);
    }
  }, []);

  return { theme, setTheme };
}
