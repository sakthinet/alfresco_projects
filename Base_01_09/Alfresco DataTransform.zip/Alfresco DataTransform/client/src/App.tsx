import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout/Layout";
import { useAuth } from "@/hooks/useAuth";

// Pages
import Home from "@/pages/Home";
import Configurations from "@/pages/Configurations";
import Reports from "@/pages/Reports";
import Migration from "@/pages/Migration";
import Templates from "@/pages/Templates";
import Login from "@/pages/Login";
import Signup from "@/pages/Signup";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      {/* Login/Signup pages without layout */}
      <Route path="/login" component={Login} />
      <Route path="/signup" component={Signup} />
      
      {/* Main application with layout */}
      <Route>
        <Layout>
          <Switch>
            <Route path="/" component={Home} />
            <Route path="/configurations" component={Configurations} />
            <Route path="/reports" component={Reports} />
            <Route path="/migration" component={Migration} />
            <Route path="/templates" component={Templates} />
            <Route component={NotFound} />
          </Switch>
        </Layout>
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
