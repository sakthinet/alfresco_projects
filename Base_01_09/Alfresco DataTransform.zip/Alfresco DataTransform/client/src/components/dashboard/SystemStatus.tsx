import { useState } from 'react';
import { EditAlfrescoModal } from '@/components/modals/EditAlfrescoModal';
import { useToast } from '@/hooks/use-toast';

interface SystemCardProps {
  title: string;
  connectionInfo: string;
  statusText: string;
  isConnected: boolean;
  isValidating?: boolean;
  onEdit?: () => void;
  onValidate?: () => void;
}

function SystemCard({ title, connectionInfo, statusText, isConnected, isValidating, onEdit, onValidate }: SystemCardProps) {
  return (
    <div 
      className="rounded-lg p-6 border hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
      style={{
        backgroundColor: 'var(--bg-primary)',
        borderColor: 'var(--border-color)',
        boxShadow: '0 4px 20px rgba(0,0,0,0.1)'
      }}
    >
      <h3 
        className="text-lg font-semibold mb-3"
        style={{ color: 'var(--text-primary)' }}
      >
        {title}
      </h3>
      
      {connectionInfo && (
        <div 
          className="text-sm mb-4"
          style={{ color: 'var(--text-secondary)' }}
        >
          {connectionInfo}
        </div>
      )}
      
      <div className="mb-4">
        {isValidating ? (
          <div className="flex items-center gap-2">
            <div className="spinner-border spinner-border-sm text-primary" role="status"></div>
            <span style={{ color: 'var(--text-secondary)' }}>{statusText}</span>
          </div>
        ) : (
          <span 
            className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium ${
              isConnected 
                ? 'bg-green-500 text-white' 
                : 'bg-red-500 text-white'
            }`}
          >
            <i className={`fas ${isConnected ? 'fa-check-circle' : 'fa-times-circle'}`}></i>
            {statusText}
          </span>
        )}
      </div>
      
      <div className="flex gap-2">
        {onEdit && (
          <button
            onClick={onEdit}
            className="px-4 py-2 border-2 rounded-lg font-medium transition-all hover:shadow-md"
            style={{
              color: 'var(--alfresco-primary)',
              borderColor: 'var(--alfresco-primary)',
              background: 'transparent'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'var(--alfresco-primary)';
              e.currentTarget.style.color = 'white';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'transparent';
              e.currentTarget.style.color = 'var(--alfresco-primary)';
            }}
            data-testid="button-edit"
          >
            <i className="fas fa-edit mr-2"></i>
            Edit
          </button>
        )}
        
        {onValidate && (
          <button
            onClick={onValidate}
            className="px-4 py-2 rounded-lg font-medium text-white transition-all hover:shadow-md hover:-translate-y-0.5"
            style={{ background: 'var(--alfresco-primary)' }}
            data-testid="button-validate"
          >
            <i className="fas fa-check mr-2"></i>
            Validate
          </button>
        )}
      </div>
    </div>
  );
}

export function SystemStatus() {
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isValidatingAlfresco, setIsValidatingAlfresco] = useState(false);
  const [isValidatingActiveMQ, setIsValidatingActiveMQ] = useState(false);
  const [alfrescoStatus, setAlfrescoStatus] = useState("Connection Validated Successfully");
  const [activeMQStatus, setActiveMQStatus] = useState("Active MQ connection success");
  const { toast } = useToast();

  const handleEditAlfresco = () => {
    setIsEditModalOpen(true);
  };

  const handleSaveAlfresco = (config: any) => {
    toast({
      title: "Success",
      description: "Alfresco configuration saved successfully!",
    });
  };

  const handleValidateAlfresco = () => {
    setIsValidatingAlfresco(true);
    setAlfrescoStatus("Validating connection...");
    
    setTimeout(() => {
      setAlfrescoStatus("Connection Validated Successfully");
      setIsValidatingAlfresco(false);
      toast({
        title: "Success",
        description: "Alfresco connection validated successfully!",
      });
    }, 2000);
  };

  const handleValidateActiveMQ = () => {
    setIsValidatingActiveMQ(true);
    setActiveMQStatus("Validating connection...");
    
    setTimeout(() => {
      setActiveMQStatus("Active MQ connection success");
      setIsValidatingActiveMQ(false);
      toast({
        title: "Success", 
        description: "Active MQ connection validated successfully!",
      });
    }, 1500);
  };

  return (
    <div className="mb-8">
      <div 
        className="flex items-center gap-3 mb-6"
        style={{ color: 'var(--text-primary)' }}
      >
        <i className="fas fa-server text-2xl" style={{ color: 'var(--alfresco-primary)' }}></i>
        <h2 className="text-2xl font-bold">System Status</h2>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <SystemCard
          title="Alfresco Connection"
          connectionInfo=""
          statusText={alfrescoStatus}
          isConnected={!isValidatingAlfresco}
          isValidating={isValidatingAlfresco}
          onEdit={handleEditAlfresco}
          onValidate={handleValidateAlfresco}
        />
        
        <SystemCard
          title="Active MQ"
          connectionInfo=""
          statusText={activeMQStatus}
          isConnected={!isValidatingActiveMQ}
          isValidating={isValidatingActiveMQ}
          onValidate={handleValidateActiveMQ}
        />
      </div>
      
      <EditAlfrescoModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onSave={handleSaveAlfresco}
      />
    </div>
  );
}