interface StatsCardsProps {
  total: number;
  migrated: number;
  remaining: number;
  progress: number;
}

export function StatsCards({ total, migrated, remaining, progress }: StatsCardsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <div className="stats-card gradient-primary text-white rounded-2xl p-8 text-center shadow-lg">
        <div className="text-5xl font-bold mb-2" data-testid="stats-total">
          {total.toLocaleString()}
        </div>
        <div className="text-lg opacity-90">Total Documents</div>
      </div>
      
      <div className="stats-card gradient-migrated text-white rounded-2xl p-8 text-center shadow-lg">
        <div className="text-5xl font-bold mb-2" data-testid="stats-migrated">
          {migrated.toLocaleString()}
        </div>
        <div className="text-lg opacity-90">Migrated</div>
      </div>
      
      <div className="stats-card gradient-remaining text-white rounded-2xl p-8 text-center shadow-lg">
        <div className="text-5xl font-bold mb-2" data-testid="stats-remaining">
          {remaining.toLocaleString()}
        </div>
        <div className="text-lg opacity-90">Remaining</div>
      </div>
      
      <div className="stats-card gradient-progress text-white rounded-2xl p-8 text-center shadow-lg">
        <div className="text-5xl font-bold mb-2" data-testid="stats-progress">
          {progress.toFixed(1)}%
        </div>
        <div className="text-lg opacity-90">Progress</div>
      </div>
    </div>
  );
}
