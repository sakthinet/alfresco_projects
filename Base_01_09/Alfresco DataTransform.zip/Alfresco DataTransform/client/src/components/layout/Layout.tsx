import { ReactNode } from 'react';
import { Sidebar } from './Sidebar';
import { TopNavigation } from './TopNavigation';
import { ThemeSwitcher } from './ThemeSwitcher';
import { useSidebar } from '@/hooks/useSidebar';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const { isCollapsed } = useSidebar();
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header placeholder with theme switcher */}
      <div className="relative">
        <div 
          className="h-16 border-b flex items-center justify-between px-6"
          style={{
            marginLeft: isCollapsed ? 'var(--sidebar-collapsed-width)' : 'var(--sidebar-width)',
            borderColor: 'var(--border-color)',
            backgroundColor: 'var(--bg-primary)'
          }}
        >
          <div className="flex items-center gap-4">
            {user && (
              <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                Welcome, <strong style={{ color: 'var(--text-primary)' }}>{user.username}</strong>
              </span>
            )}
          </div>
          <div className="flex items-center gap-4">
            <ThemeSwitcher />
            {user && (
              <Button
                onClick={logout}
                variant="outline"
                size="sm"
                data-testid="button-logout"
                className="flex items-center gap-2"
              >
                <i className="fas fa-sign-out-alt"></i>
                Logout
              </Button>
            )}
          </div>
        </div>
      </div>
      
      <Sidebar />
      
      {/* Main content area */}
      <div
        className="sidebar-transition flex-1 flex flex-col"
        style={{
          marginLeft: isCollapsed ? 'var(--sidebar-collapsed-width)' : 'var(--sidebar-width)'
        }}
      >
        <TopNavigation />
        <main className="px-6 flex-1">
          {children}
        </main>
        
        {/* Footer placeholder */}
        <footer 
          className="mt-auto p-4 text-center text-sm border-t"
          style={{
            backgroundColor: 'var(--bg-secondary)',
            borderColor: 'var(--border-color)',
            color: 'var(--text-secondary)'
          }}
        >
          © 2025 TCS Data Migrator for Alfresco. All rights reserved.
        </footer>
      </div>
    </div>
  );
}
