import { Link, useLocation } from 'wouter';
import { useSidebar } from '@/hooks/useSidebar';
import type { NavigationItem } from '@/lib/types';

const navigationItems: NavigationItem[] = [
  { id: 'home', label: 'Home', icon: 'fa-home', path: '/' },
  { id: 'configurations', label: 'Configurations', icon: 'fa-cog', path: '/configurations' },
  { id: 'reports', label: 'Reports', icon: 'fa-chart-bar', path: '/reports' },
  { id: 'migration', label: 'Migration', icon: 'fa-exchange-alt', path: '/migration' },
  { id: 'templates', label: 'Templates', icon: 'fa-file-alt', path: '/templates' },
];

export function Sidebar() {
  const { isCollapsed, toggleSidebar } = useSidebar();
  const [location] = useLocation();

  return (
    <div
      className="fixed left-0 top-0 h-screen z-40 sidebar-transition gradient-primary shadow-2xl"
      style={{
        width: isCollapsed ? 'var(--sidebar-collapsed-width)' : 'var(--sidebar-width)'
      }}
    >
      <button
        data-testid="sidebar-toggle"
        onClick={toggleSidebar}
        className="absolute -right-4 top-4 w-8 h-8 rounded-full flex items-center justify-center text-white shadow-lg z-50 sidebar-transition"
        style={{ background: 'var(--alfresco-primary)' }}
      >
        <i className={`fas fa-chevron-${isCollapsed ? 'right' : 'left'} text-sm`}></i>
      </button>
      
      <div className="flex items-center gap-3 p-6 border-b border-white/20">
        <i className="fas fa-database text-2xl text-white"></i>
        <span
          className={`text-xl font-semibold text-white sidebar-transition ${
            isCollapsed ? 'opacity-0' : 'opacity-100'
          }`}
        >
          {!isCollapsed && 'Alfresco Data Transformer'}
        </span>
      </div>
      
      <nav className="mt-6">
        <div className="px-3">
          {navigationItems.map((item) => {
            const isActive = location === item.path;
            return (
              <Link
                key={item.id}
                href={item.path}
                data-testid={`nav-${item.id}`}
                className={`nav-link ${isActive ? 'active' : ''}`}
              >
                <i className={`fas ${item.icon} w-5 text-center`}></i>
                <span
                  className={`sidebar-transition ${
                    isCollapsed ? 'opacity-0' : 'opacity-100'
                  }`}
                >
                  {!isCollapsed && item.label}
                </span>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
