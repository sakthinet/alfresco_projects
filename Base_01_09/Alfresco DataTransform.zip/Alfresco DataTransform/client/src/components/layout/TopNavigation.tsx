import { useLocation } from 'wouter';

const pageConfig = {
  '/': { title: 'Home Dashboard', icon: 'fa-home' },
  '/configurations': { title: 'Configurations', icon: 'fa-cog' },
  '/reports': { title: 'Reports', icon: 'fa-chart-bar' },
  '/migration': { title: 'Migration', icon: 'fa-exchange-alt' },
  '/templates': { title: 'Templates', icon: 'fa-file-alt' },
};

export function TopNavigation() {
  const [location] = useLocation();
  const config = pageConfig[location as keyof typeof pageConfig] || pageConfig['/'];

  return (
    <div
      className="p-6 mb-6 rounded-b-2xl shadow-sm"
      style={{ backgroundColor: 'var(--bg-primary)' }}
    >
      <div className="flex items-center justify-between">
        <h1
          className="text-3xl font-bold flex items-center gap-4"
          style={{ color: 'var(--text-primary)' }}
        >
          <i className={`fas ${config.icon}`}></i>
          {config.title}
        </h1>
        <div className="flex items-center gap-4">
          <div
            className="text-sm"
            style={{ color: 'var(--text-secondary)' }}
          >
            <span>Last sync: 2 minutes ago</span>
          </div>
          <button
            data-testid="refresh-button"
            className="px-4 py-2 rounded-lg text-white shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all"
            style={{ background: 'var(--alfresco-primary)' }}
          >
            <i className="fas fa-sync-alt mr-2"></i>
            Refresh
          </button>
        </div>
      </div>
    </div>
  );
}
