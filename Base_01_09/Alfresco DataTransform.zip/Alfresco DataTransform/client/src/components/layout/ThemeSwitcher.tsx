import { useState } from 'react';
import { useTheme } from '@/hooks/useTheme';
import type { Theme } from '@/lib/types';

const themes: { value: Theme; label: string; icon: string }[] = [
  { value: 'light', label: 'Light', icon: 'fa-sun' },
  { value: 'dark', label: 'Dark', icon: 'fa-moon' },
  { value: 'custom', label: 'Custom', icon: 'fa-magic' },
  { value: 'hyland', label: 'Hyland Alfresco', icon: 'fa-leaf' },
];

export function ThemeSwitcher() {
  const { theme, setTheme } = useTheme();
  const [isOpen, setIsOpen] = useState(false);

  const currentTheme = themes.find(t => t.value === theme);

  return (
    <div className="relative z-50">
      <div className="relative">
        <button
          data-testid="theme-switcher-button"
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center gap-2 px-3 py-2 text-sm border rounded-lg transition-colors hover:bg-opacity-50"
          style={{
            borderColor: 'var(--border-color)',
            backgroundColor: 'var(--bg-primary)',
            color: 'var(--text-primary)'
          }}
        >
          <i className="fas fa-palette"></i>
          <span>Theme</span>
          <i className={`fas fa-chevron-${isOpen ? 'up' : 'down'} text-xs transition-transform`}></i>
        </button>
        
        {isOpen && (
          <div
            className="absolute right-0 mt-1 w-48 rounded-lg shadow-lg border z-50"
            style={{
              backgroundColor: 'var(--bg-primary)',
              borderColor: 'var(--border-color)'
            }}
          >
            <div className="py-1">
              {themes.map((themeOption) => (
                <button
                  key={themeOption.value}
                  data-testid={`theme-option-${themeOption.value}`}
                  onClick={() => {
                    setTheme(themeOption.value);
                    setIsOpen(false);
                  }}
                  className="theme-button"
                >
                  <i className={`fas ${themeOption.icon} ${
                    themeOption.value === 'light' ? 'text-yellow-500' :
                    themeOption.value === 'dark' ? 'text-indigo-500' :
                    themeOption.value === 'custom' ? 'text-purple-500' :
                    'text-blue-600'
                  }`}></i>
                  <span>{themeOption.label}</span>
                  {theme === themeOption.value && (
                    <i className="fas fa-check ml-auto"></i>
                  )}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
      
      {isOpen && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => setIsOpen(false)}
        />
      )}
    </div>
  );
}
