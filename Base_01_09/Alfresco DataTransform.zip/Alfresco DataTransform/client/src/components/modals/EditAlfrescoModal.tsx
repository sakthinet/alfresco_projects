import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface EditAlfrescoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (config: AlfrescoConfig) => void;
}

interface AlfrescoConfig {
  configId: string;
  protocol: string;
  host: string;
  port: string;
  username: string;
  password: string;
}

export function EditAlfrescoModal({ isOpen, onClose, onSave }: EditAlfrescoModalProps) {
  const [config, setConfig] = useState<AlfrescoConfig>({
    configId: '4',
    protocol: 'HTTP',
    host: 'localhost',
    port: '8080',
    username: 'admin',
    password: '••••••'
  });

  const handleSave = () => {
    onSave(config);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
            <i className="fas fa-edit"></i>
            Edit Alfresco Details
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="configId" style={{ color: 'var(--text-primary)' }}>Config ID</Label>
            <Input
              id="configId"
              value={config.configId}
              readOnly
              className="form-control-custom"
              style={{
                backgroundColor: 'var(--input-bg)',
                borderColor: 'var(--border-color)',
                color: 'var(--text-primary)'
              }}
              data-testid="input-config-id"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="protocol" style={{ color: 'var(--text-primary)' }}>
              Protocol <span className="text-red-500">*</span>
            </Label>
            <Select value={config.protocol} onValueChange={(value) => setConfig({...config, protocol: value})}>
              <SelectTrigger 
                className="form-control-custom"
                style={{
                  backgroundColor: 'var(--input-bg)',
                  borderColor: 'var(--border-color)',
                  color: 'var(--text-primary)'
                }}
                data-testid="select-protocol"
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="HTTP">HTTP</SelectItem>
                <SelectItem value="HTTPS">HTTPS</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="host" style={{ color: 'var(--text-primary)' }}>
              Host <span className="text-red-500">*</span>
            </Label>
            <Input
              id="host"
              value={config.host}
              onChange={(e) => setConfig({...config, host: e.target.value})}
              required
              className="form-control-custom"
              style={{
                backgroundColor: 'var(--input-bg)',
                borderColor: 'var(--border-color)',
                color: 'var(--text-primary)'
              }}
              data-testid="input-host"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="port" style={{ color: 'var(--text-primary)' }}>
              Port <span className="text-red-500">*</span>
            </Label>
            <Select value={config.port} onValueChange={(value) => setConfig({...config, port: value})}>
              <SelectTrigger 
                className="form-control-custom"
                style={{
                  backgroundColor: 'var(--input-bg)',
                  borderColor: 'var(--border-color)',
                  color: 'var(--text-primary)'
                }}
                data-testid="select-port"
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="8080">8080</SelectItem>
                <SelectItem value="8443">8443</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="username" style={{ color: 'var(--text-primary)' }}>
              Username <span className="text-red-500">*</span>
            </Label>
            <Input
              id="username"
              value={config.username}
              onChange={(e) => setConfig({...config, username: e.target.value})}
              required
              className="form-control-custom"
              style={{
                backgroundColor: 'var(--input-bg)',
                borderColor: 'var(--border-color)',
                color: 'var(--text-primary)'
              }}
              data-testid="input-username"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="password" style={{ color: 'var(--text-primary)' }}>
              Password <span className="text-red-500">*</span>
            </Label>
            <Input
              id="password"
              type="password"
              value={config.password}
              onChange={(e) => setConfig({...config, password: e.target.value})}
              required
              className="form-control-custom"
              style={{
                backgroundColor: 'var(--input-bg)',
                borderColor: 'var(--border-color)',
                color: 'var(--text-primary)'
              }}
              data-testid="input-password"
            />
          </div>
        </div>
        
        <DialogFooter className="gap-2">
          <Button
            variant="secondary"
            onClick={onClose}
            className="flex items-center gap-2"
            data-testid="button-cancel"
          >
            <i className="fas fa-times"></i>
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            className="flex items-center gap-2"
            style={{ background: 'var(--alfresco-primary)', color: 'white' }}
            data-testid="button-save"
          >
            <i className="fas fa-save"></i>
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}