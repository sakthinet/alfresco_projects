import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

type ConfigTab = 'alfresco-config' | 'activemq-config' | 'csv-mapping';

const tabs = [
  { id: 'alfresco-config' as ConfigTab, label: 'Alfresco', icon: 'fa-server' },
  { id: 'activemq-config' as ConfigTab, label: 'Active MQ', icon: 'fa-network-wired' },
  { id: 'csv-mapping' as ConfigTab, label: 'CSV Metadata Mapping', icon: 'fa-file-csv' },
];

export default function Configurations() {
  const [activeTab, setActiveTab] = useState<ConfigTab>('alfresco-config');
  const [templateName, setTemplateName] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [selectedAspect, setSelectedAspect] = useState('');

  const handleValidateAlfresco = () => {
    console.log('Validating Alfresco connection...');
  };

  const handleSaveAlfresco = () => {
    console.log('Saving Alfresco configuration...');
  };

  const handleValidateActiveMQ = () => {
    console.log('Validating Active MQ connection...');
  };

  const handleLockType = () => {
    console.log('Locking type selection...');
  };

  const handleReset = () => {
    console.log('Resetting mapping configuration...');
    setTemplateName('');
    setSelectedType('');
    setSelectedAspect('');
  };

  const handleMapColumn = () => {
    console.log('Mapping column...');
  };

  const handleSaveMapping = () => {
    console.log('Saving mapping configuration...');
  };

  return (
    <div>
      {/* Navigation Tabs */}
      <div className="mb-6">
        <nav className="flex space-x-0 border-b-2" style={{ borderColor: 'var(--alfresco-primary)' }}>
          {tabs.map((tab) => (
            <button
              key={tab.id}
              data-testid={`tab-${tab.id}`}
              onClick={() => setActiveTab(tab.id)}
              className={`px-6 py-3 font-medium transition-all flex items-center gap-2 ${
                activeTab === tab.id
                  ? 'text-white rounded-t-lg'
                  : 'hover:bg-opacity-10'
              }`}
              style={
                activeTab === tab.id
                  ? { background: 'var(--alfresco-primary)' }
                  : { color: 'var(--text-primary)' }
              }
            >
              <i className={`fas ${tab.icon}`}></i>
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Alfresco Configuration Tab */}
      {activeTab === 'alfresco-config' && (
        <div
          className="rounded-2xl p-8 border"
          style={{
            background: 'linear-gradient(135deg, var(--bg-secondary), var(--bg-primary))',
            borderColor: 'var(--border-color)'
          }}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="config-id" className="block text-sm font-semibold mb-2">
                Config ID
              </Label>
              <Input
                id="config-id"
                data-testid="input-config-id"
                type="text"
                value="4"
                readOnly
                className="w-full bg-gray-100"
              />
            </div>
            <div>
              <Label htmlFor="protocol" className="block text-sm font-semibold mb-2">
                Protocol <span className="text-red-500">*</span>
              </Label>
              <Select defaultValue="HTTP">
                <SelectTrigger data-testid="select-protocol">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="HTTP">HTTP</SelectItem>
                  <SelectItem value="HTTPS">HTTPS</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="host" className="block text-sm font-semibold mb-2">
                Host <span className="text-red-500">*</span>
              </Label>
              <Input
                id="host"
                data-testid="input-host"
                type="text"
                defaultValue="localhost"
                className="w-full"
                required
              />
            </div>
            <div>
              <Label htmlFor="port" className="block text-sm font-semibold mb-2">
                Port <span className="text-red-500">*</span>
              </Label>
              <Select defaultValue="8080">
                <SelectTrigger data-testid="select-port">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="8080">8080</SelectItem>
                  <SelectItem value="8443">8443</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="username" className="block text-sm font-semibold mb-2">
                Username
              </Label>
              <Input
                id="username"
                data-testid="input-username"
                type="text"
                defaultValue="admin"
                className="w-full"
              />
            </div>
            <div>
              <Label htmlFor="password" className="block text-sm font-semibold mb-2">
                Password
              </Label>
              <Input
                id="password"
                data-testid="input-password"
                type="password"
                defaultValue="••••••"
                className="w-full"
              />
            </div>
          </div>
          
          <div className="mt-8 flex gap-4 justify-end">
            <Button
              data-testid="button-save-alfresco"
              onClick={handleSaveAlfresco}
              variant="outline"
              className="px-6 py-2"
            >
              <i className="fas fa-save mr-2"></i>
              Save
            </Button>
            <Button
              data-testid="button-validate-alfresco"
              onClick={handleValidateAlfresco}
              className="px-6 py-2 text-white"
              style={{ background: 'var(--alfresco-primary)' }}
            >
              <i className="fas fa-check mr-2"></i>
              Validate
            </Button>
          </div>
        </div>
      )}

      {/* Active MQ Configuration Tab */}
      {activeTab === 'activemq-config' && (
        <div
          className="rounded-2xl p-8 border"
          style={{
            background: 'linear-gradient(135deg, var(--bg-secondary), var(--bg-primary))',
            borderColor: 'var(--border-color)'
          }}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="amq-protocol" className="block text-sm font-semibold mb-2">
                Protocol <span className="text-red-500">*</span>
              </Label>
              <Input
                id="amq-protocol"
                data-testid="input-amq-protocol"
                type="text"
                defaultValue="tcp"
                className="w-full"
                required
              />
            </div>
            <div>
              <Label htmlFor="amq-host" className="block text-sm font-semibold mb-2">
                Host <span className="text-red-500">*</span>
              </Label>
              <Input
                id="amq-host"
                data-testid="input-amq-host"
                type="text"
                defaultValue="localhost"
                className="w-full"
                required
              />
            </div>
            <div>
              <Label htmlFor="amq-port" className="block text-sm font-semibold mb-2">
                Port <span className="text-red-500">*</span>
              </Label>
              <Input
                id="amq-port"
                data-testid="input-amq-port"
                type="text"
                defaultValue="61616"
                className="w-full"
                required
              />
            </div>
            <div>
              <Label htmlFor="amq-username" className="block text-sm font-semibold mb-2">
                Username
              </Label>
              <Input
                id="amq-username"
                data-testid="input-amq-username"
                type="text"
                defaultValue="admin"
                className="w-full"
              />
            </div>
            <div>
              <Label htmlFor="amq-password" className="block text-sm font-semibold mb-2">
                Password
              </Label>
              <Input
                id="amq-password"
                data-testid="input-amq-password"
                type="password"
                defaultValue="••••"
                className="w-full"
              />
            </div>
          </div>
          
          <div className="mt-8 flex justify-end">
            <Button
              data-testid="button-validate-activemq"
              onClick={handleValidateActiveMQ}
              className="px-6 py-2 text-white"
              style={{ background: 'var(--alfresco-primary)' }}
            >
              <i className="fas fa-check mr-2"></i>
              Validate
            </Button>
          </div>
        </div>
      )}

      {/* CSV Metadata Mapping Tab */}
      {activeTab === 'csv-mapping' && (
        <div
          className="rounded-2xl p-8 border"
          style={{
            background: 'linear-gradient(135deg, var(--bg-secondary), var(--bg-primary))',
            borderColor: 'var(--border-color)'
          }}
        >
          {/* Top Configuration Row */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            <div>
              <Label htmlFor="template-name" className="block text-sm font-semibold mb-2">
                Template Name
              </Label>
              <Input
                id="template-name"
                data-testid="input-template-name"
                type="text"
                placeholder="Enter template name"
                value={templateName}
                onChange={(e) => setTemplateName(e.target.value)}
                className="w-full"
              />
            </div>
            <div>
              <Label htmlFor="select-type" className="block text-sm font-semibold mb-2">
                Select Type
              </Label>
              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger data-testid="select-type">
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="content">Content</SelectItem>
                  <SelectItem value="folder">Folder</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="select-aspect" className="block text-sm font-semibold mb-2">
                Select Aspect
              </Label>
              <Select value={selectedAspect} onValueChange={setSelectedAspect}>
                <SelectTrigger data-testid="select-aspect">
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cm:titled">cm:titled</SelectItem>
                  <SelectItem value="cm:author">cm:author</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="file-template" className="block text-sm font-semibold mb-2">
                Select File Template
                <i className="fas fa-info-circle text-gray-400 ml-2" title="Upload CSV file template"></i>
              </Label>
              <div className="flex">
                <Input
                  id="file-template"
                  data-testid="input-file-template"
                  type="file"
                  accept=".csv"
                  className="w-full"
                />
              </div>
              <small className="text-gray-500">No file chosen</small>
            </div>
          </div>

          {/* Lock Type and Reset Row */}
          <div className="flex justify-between items-center mb-6">
            <Button
              data-testid="button-lock-type"
              onClick={handleLockType}
              className="px-6 py-2 text-white"
              style={{ background: 'var(--alfresco-primary)' }}
            >
              <i className="fas fa-lock mr-2"></i>
              Lock Type
            </Button>
            <div className="text-right">
              <div className="text-sm mb-2" style={{ color: 'var(--text-secondary)' }}>
                <strong>Selected Filetype:</strong><br/>
                <strong>Physical File Column:</strong>
              </div>
              <Button
                data-testid="button-reset"
                onClick={handleReset}
                variant="outline"
                className="px-4 py-2"
              >
                <i className="fas fa-undo mr-2"></i>
                Reset
              </Button>
            </div>
          </div>

          {/* Mapping Cards Row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            {/* CSV Columns */}
            <div
              className="border rounded-lg"
              style={{ borderColor: 'var(--border-color)' }}
            >
              <div
                className="px-4 py-3 text-white font-semibold rounded-t-lg"
                style={{ background: 'var(--alfresco-primary)' }}
              >
                <i className="fas fa-table mr-2"></i>
                CSV Columns
              </div>
              <div className="p-6 h-48 flex items-center justify-center">
                <div className="text-center" style={{ color: 'var(--text-secondary)' }}>
                  <i className="fas fa-file-csv text-4xl mb-3 opacity-50"></i>
                  <p>No CSV added</p>
                </div>
              </div>
            </div>

            {/* Alfresco Metadata */}
            <div
              className="border rounded-lg"
              style={{ borderColor: 'var(--border-color)' }}
            >
              <div className="px-4 py-3 bg-cyan-500 text-white font-semibold rounded-t-lg">
                <i className="fas fa-database mr-2"></i>
                Alfresco Metadata
              </div>
              <div className="p-6 h-48 flex items-center justify-center">
                <div className="text-center" style={{ color: 'var(--text-secondary)' }}>
                  <i className="fas fa-cog text-4xl mb-3 opacity-50"></i>
                  <p>No Type Selected</p>
                </div>
              </div>
            </div>

            {/* Mapped Metadata */}
            <div
              className="border rounded-lg"
              style={{ borderColor: 'var(--border-color)' }}
            >
              <div className="px-4 py-3 bg-green-500 text-white font-semibold rounded-t-lg">
                <i className="fas fa-check mr-2"></i>
                Mapped Metadata
              </div>
              <div className="p-6 h-48 flex items-center justify-center">
                <div className="text-center" style={{ color: 'var(--text-secondary)' }}>
                  <i className="fas fa-link text-4xl mb-3 opacity-50"></i>
                  <p>No Mapped Metadata</p>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="text-center">
            <Button
              data-testid="button-map-column"
              onClick={handleMapColumn}
              className="px-6 py-2 text-white mr-4"
              style={{ background: 'var(--alfresco-primary)' }}
            >
              <i className="fas fa-map mr-2"></i>
              Map Column
            </Button>
            <Button
              data-testid="button-save-mapping"
              onClick={handleSaveMapping}
              className="px-6 py-2 bg-green-500 text-white"
            >
              <i className="fas fa-save mr-2"></i>
              Save Mapping
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
