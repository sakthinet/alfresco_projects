import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';

export default function Migration() {
  const [hasIncludeColumn, setHasIncludeColumn] = useState('no');
  const [sourceLocation, setSourceLocation] = useState('local');
  const [isLatest, setIsLatest] = useState(true);
  const [metadataTemplate, setMetadataTemplate] = useState('');
  const [nativeMetadataTemplate, setNativeMetadataTemplate] = useState('');

  // Migration progress data
  const [migrationStats, setMigrationStats] = useState({
    totalRecords: '-',
    remainingRecords: '-',
    timeTaken: '-'
  });

  const handleStartMigration = () => {
    console.log('Starting CSV migration...');
    // Simulate migration start
    setMigrationStats({
      totalRecords: '1,247',
      remainingRecords: '856',
      timeTaken: '00:15:32'
    });
  };

  const handleResetMigration = () => {
    console.log('Resetting migration form...');
    setHasIncludeColumn('no');
    setSourceLocation('local');
    setIsLatest(true);
    setMetadataTemplate('');
    setNativeMetadataTemplate('');
    setMigrationStats({
      totalRecords: '-',
      remainingRecords: '-',
      timeTaken: '-'
    });
  };

  return (
    <div
      className="rounded-2xl p-8 border"
      style={{
        background: 'linear-gradient(135deg, var(--bg-secondary), var(--bg-primary))',
        borderColor: 'var(--border-color)'
      }}
    >
      <div
        className="flex items-center gap-3 mb-6 pb-4 border-b"
        style={{ borderColor: 'var(--border-color)' }}
      >
        <i className="fas fa-file-csv text-xl" style={{ color: 'var(--alfresco-primary)' }}></i>
        <h3 className="text-xl font-semibold" style={{ color: 'var(--text-primary)' }}>
          CSV Migration
        </h3>
      </div>

      {/* Has Include Column */}
      <div className="mb-6">
        <Label className="text-sm font-bold mb-3 block">Has Include Column?</Label>
        <RadioGroup
          value={hasIncludeColumn}
          onValueChange={setHasIncludeColumn}
          className="flex gap-6"
        >
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="yes" id="include-yes" data-testid="radio-include-yes" />
            <Label htmlFor="include-yes">Yes</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="no" id="include-no" data-testid="radio-include-no" />
            <Label htmlFor="include-no">No</Label>
          </div>
        </RadioGroup>
      </div>

      {/* Select CSV */}
      <div className="grid grid-cols-12 gap-4 items-end mb-4">
        <div className="col-span-2">
          <Label className="text-sm font-bold">Select CSV</Label>
        </div>
        <div className="col-span-6">
          <div className="flex">
            <Input
              type="file"
              accept=".csv"
              data-testid="input-csv-file"
              className="flex-1"
            />
          </div>
          <small className="text-gray-500 mt-1">No file chosen</small>
        </div>
      </div>

      {/* Select Destination */}
      <div className="grid grid-cols-12 gap-4 items-end mb-4">
        <div className="col-span-2">
          <Label className="text-sm font-bold">Select Destination</Label>
        </div>
        <div className="col-span-6">
          <div className="flex">
            <Input
              type="text"
              placeholder="Enter destination path"
              data-testid="input-destination"
              className="flex-1"
            />
            <Button
              variant="outline"
              size="sm"
              className="ml-2"
              data-testid="button-browse-destination"
            >
              <i className="fas fa-ellipsis-h"></i>
            </Button>
          </div>
        </div>
      </div>

      {/* Select Native Files Destination */}
      <div className="grid grid-cols-12 gap-4 items-end mb-4">
        <div className="col-span-2">
          <Label className="text-sm font-bold">Select Native Files Destination</Label>
        </div>
        <div className="col-span-6">
          <div className="flex">
            <Input
              type="text"
              placeholder="Enter native files destination"
              data-testid="input-native-destination"
              className="flex-1"
            />
            <Button
              variant="outline"
              size="sm"
              className="ml-2"
              data-testid="button-browse-native-destination"
            >
              <i className="fas fa-ellipsis-h"></i>
            </Button>
          </div>
        </div>
      </div>

      {/* Source Location */}
      <div className="grid grid-cols-12 gap-4 items-center mb-4">
        <div className="col-span-2">
          <Label className="text-sm font-bold">Source Location</Label>
        </div>
        <div className="col-span-6">
          <RadioGroup
            value={sourceLocation}
            onValueChange={setSourceLocation}
            className="flex gap-6"
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="local" id="source-local" data-testid="radio-source-local" />
              <Label htmlFor="source-local">Local</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="amazon-s3" id="source-s3" data-testid="radio-source-s3" />
              <Label htmlFor="source-s3">Amazon S3</Label>
            </div>
          </RadioGroup>
        </div>
      </div>

      {/* Local PDF Files Location */}
      <div className="grid grid-cols-12 gap-4 items-end mb-4">
        <div className="col-span-2">
          <Label className="text-sm font-bold">Local PDF Files Location</Label>
        </div>
        <div className="col-span-6">
          <Input
            type="text"
            placeholder="Enter local PDF files path"
            data-testid="input-pdf-location"
          />
        </div>
      </div>

      {/* Local Native Files Location */}
      <div className="grid grid-cols-12 gap-4 items-end mb-4">
        <div className="col-span-2">
          <Label className="text-sm font-bold">Local Native Files Location</Label>
        </div>
        <div className="col-span-6">
          <Input
            type="text"
            placeholder="Enter local native files path"
            data-testid="input-native-location"
          />
        </div>
      </div>

      {/* Is Latest */}
      <div className="grid grid-cols-12 gap-4 items-center mb-4">
        <div className="col-span-2">
          <Label className="text-sm font-bold">Is Latest?</Label>
        </div>
        <div className="col-span-6">
          <div className="flex items-center space-x-2">
            <Checkbox
              id="is-latest"
              checked={isLatest}
              onCheckedChange={setIsLatest}
              data-testid="checkbox-is-latest"
            />
            <Label htmlFor="is-latest"></Label>
          </div>
        </div>
      </div>

      {/* Template Selection Row */}
      <div className="grid grid-cols-12 gap-4 items-end mb-6">
        <div className="col-span-2">
          <Label className="text-sm font-bold">Metadata Template</Label>
        </div>
        <div className="col-span-3">
          <Select value={metadataTemplate} onValueChange={setMetadataTemplate}>
            <SelectTrigger data-testid="select-metadata-template">
              <SelectValue placeholder="Select Template" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="template1">Template 1</SelectItem>
              <SelectItem value="template2">Template 2</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="col-span-2">
          <Label className="text-sm font-bold">Native Metadata Template</Label>
        </div>
        <div className="col-span-3">
          <Select value={nativeMetadataTemplate} onValueChange={setNativeMetadataTemplate}>
            <SelectTrigger data-testid="select-native-template">
              <SelectValue placeholder="Select Native Template" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="native1">Native Template 1</SelectItem>
              <SelectItem value="native2">Native Template 2</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="text-center mb-6">
        <Button
          data-testid="button-migrate"
          onClick={handleStartMigration}
          className="px-8 py-3 text-white text-lg font-medium mr-4"
          style={{ background: 'var(--alfresco-primary)' }}
        >
          <i className="fas fa-play mr-2"></i>
          Migrate
        </Button>
        <Button
          data-testid="button-reset"
          onClick={handleResetMigration}
          variant="outline"
          className="px-8 py-3 text-lg font-medium"
        >
          <i className="fas fa-undo mr-2"></i>
          Reset
        </Button>
      </div>

      {/* Migration Progress Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div>
          <div className="font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>
            Total Records:
          </div>
          <div
            data-testid="total-records"
            className="text-lg"
            style={{ color: 'var(--text-secondary)' }}
          >
            {migrationStats.totalRecords}
          </div>
        </div>
        <div>
          <div className="font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>
            Remaining:
          </div>
          <div
            data-testid="remaining-records"
            className="text-lg"
            style={{ color: 'var(--text-secondary)' }}
          >
            {migrationStats.remainingRecords}
          </div>
        </div>
        <div>
          <div className="font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>
            Time Taken:
          </div>
          <div
            data-testid="time-taken"
            className="text-lg"
            style={{ color: 'var(--text-secondary)' }}
          >
            {migrationStats.timeTaken}
          </div>
        </div>
      </div>

      {/* Status Table */}
      <div className="mt-6">
        <div
          className="rounded-lg border overflow-hidden"
          style={{ borderColor: 'var(--border-color)' }}
        >
          <table className="w-full">
            <thead
              className="border-b"
              style={{
                backgroundColor: 'var(--bg-secondary)',
                borderColor: 'var(--border-color)'
              }}
            >
              <tr>
                <th
                  className="px-4 py-3 text-left font-semibold"
                  style={{ color: 'var(--text-primary)' }}
                >
                  Status Code
                </th>
                <th
                  className="px-4 py-3 text-left font-semibold"
                  style={{ color: 'var(--text-primary)' }}
                >
                  Status Message
                </th>
                <th
                  className="px-4 py-3 text-left font-semibold"
                  style={{ color: 'var(--text-primary)' }}
                >
                  Count
                </th>
              </tr>
            </thead>
            <tbody data-testid="migration-status-table">
              <tr>
                <td
                  className="px-4 py-6 text-center"
                  colSpan={3}
                  style={{ color: 'var(--text-secondary)' }}
                >
                  No records migrated
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
