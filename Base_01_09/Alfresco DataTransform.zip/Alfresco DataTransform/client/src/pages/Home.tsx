import { StatsCards } from '@/components/dashboard/StatsCards';
import { SystemStatus } from '@/components/dashboard/SystemStatus';

export default function Home() {
  // In a real application, this data would come from an API
  const stats = {
    total: 1247,
    migrated: 856,
    remaining: 391,
    progress: 68.6
  };

  return (
    <div>
      <StatsCards {...stats} />
      <SystemStatus />
    </div>
  );
}
