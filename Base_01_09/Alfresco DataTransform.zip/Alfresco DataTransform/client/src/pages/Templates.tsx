import { Button } from '@/components/ui/button';

interface TemplateCardProps {
  title: string;
  description: string;
  onUse: () => void;
  onEdit: () => void;
}

function TemplateCard({ title, description, onUse, onEdit }: TemplateCardProps) {
  return (
    <div
      className="rounded-2xl p-6 border hover:shadow-lg transition-all"
      style={{
        backgroundColor: 'var(--bg-primary)',
        borderColor: 'var(--border-color)'
      }}
    >
      <h3
        className="text-lg font-semibold mb-2"
        style={{ color: 'var(--text-primary)' }}
      >
        {title}
      </h3>
      <p
        className="text-sm mb-4"
        style={{ color: 'var(--text-secondary)' }}
      >
        {description}
      </p>
      <div className="flex gap-2">
        <Button
          data-testid={`button-use-${title.toLowerCase().replace(/\s+/g, '-')}`}
          onClick={onUse}
          className="px-4 py-2 text-white rounded-lg text-sm font-medium transition-all"
          style={{ background: 'var(--alfresco-primary)' }}
        >
          Use Template
        </Button>
        <Button
          data-testid={`button-edit-${title.toLowerCase().replace(/\s+/g, '-')}`}
          onClick={onEdit}
          variant="outline"
          className="px-4 py-2 border rounded-lg text-sm font-medium transition-all"
        >
          Edit
        </Button>
      </div>
    </div>
  );
}

function CreateTemplateCard({ onCreate }: { onCreate: () => void }) {
  return (
    <div
      className="rounded-2xl p-6 border-2 border-dashed transition-all hover:border-solid cursor-pointer"
      style={{ borderColor: 'var(--border-color)' }}
      onClick={onCreate}
      data-testid="card-create-template"
    >
      <div className="text-center">
        <i
          className="fas fa-plus text-4xl mb-4"
          style={{ color: 'var(--text-secondary)' }}
        ></i>
        <h3
          className="text-lg font-semibold mb-2"
          style={{ color: 'var(--text-primary)' }}
        >
          Create New Template
        </h3>
        <p
          className="text-sm"
          style={{ color: 'var(--text-secondary)' }}
        >
          Design a custom migration template
        </p>
      </div>
    </div>
  );
}

export default function Templates() {
  const templates = [
    {
      title: 'Document Migration Template',
      description: 'Standard template for document migration with metadata preservation'
    },
    {
      title: 'Folder Structure Template',
      description: 'Template for migrating complex folder hierarchies'
    }
  ];

  const handleUseTemplate = (templateName: string) => {
    console.log(`Using template: ${templateName}`);
  };

  const handleEditTemplate = (templateName: string) => {
    console.log(`Editing template: ${templateName}`);
  };

  const handleCreateTemplate = () => {
    console.log('Creating new template...');
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {templates.map((template) => (
        <TemplateCard
          key={template.title}
          title={template.title}
          description={template.description}
          onUse={() => handleUseTemplate(template.title)}
          onEdit={() => handleEditTemplate(template.title)}
        />
      ))}
      
      <CreateTemplateCard onCreate={handleCreateTemplate} />
    </div>
  );
}
