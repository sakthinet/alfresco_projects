import { Button } from '@/components/ui/button';

export default function Reports() {
  const handleGenerateReport = () => {
    console.log('Generating custom report...');
  };

  const reportSections = [
    {
      title: 'Migration Reports',
      items: [
        'Daily Migration Summary',
        'Failed Migrations Report',
        'Performance Analytics'
      ]
    },
    {
      title: 'System Reports',
      items: [
        'Connection Status Report',
        'System Health Check'
      ]
    }
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
      {reportSections.map((section) => (
        <div
          key={section.title}
          className="rounded-2xl p-6 border"
          style={{
            backgroundColor: 'var(--bg-primary)',
            borderColor: 'var(--border-color)'
          }}
        >
          <h3
            className="text-lg font-semibold mb-4"
            style={{ color: 'var(--text-primary)' }}
          >
            {section.title}
          </h3>
          <ul className="space-y-2">
            {section.items.map((item) => (
              <li key={item}>
                <a
                  href="#"
                  data-testid={`link-${item.toLowerCase().replace(/\s+/g, '-')}`}
                  className="text-blue-500 hover:underline"
                  onClick={(e) => {
                    e.preventDefault();
                    console.log(`Opening report: ${item}`);
                  }}
                >
                  {item}
                </a>
              </li>
            ))}
          </ul>
        </div>
      ))}
      
      <div
        className="rounded-2xl p-6 border"
        style={{
          backgroundColor: 'var(--bg-primary)',
          borderColor: 'var(--border-color)'
        }}
      >
        <h3
          className="text-lg font-semibold mb-4"
          style={{ color: 'var(--text-primary)' }}
        >
          Custom Reports
        </h3>
        <Button
          data-testid="button-generate-custom-report"
          onClick={handleGenerateReport}
          className="w-full px-4 py-2 text-white rounded-lg font-medium transition-all hover:shadow-lg"
          style={{ background: 'var(--alfresco-primary)' }}
        >
          Generate Custom Report
        </Button>
      </div>
    </div>
  );
}
