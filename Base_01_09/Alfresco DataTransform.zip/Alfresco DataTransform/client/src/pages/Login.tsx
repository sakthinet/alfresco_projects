import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Link, useLocation } from 'wouter';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [, setLocation] = useLocation();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simple redirect to home page
    setLocation('/');
  };

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
      <div className="w-full max-w-md">
        <div
          className="rounded-2xl p-8 border shadow-lg"
          style={{
            background: 'linear-gradient(135deg, var(--bg-secondary), var(--bg-primary))',
            borderColor: 'var(--border-color)'
          }}
        >
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-3 mb-4">
              <i className="fas fa-database text-3xl" style={{ color: 'var(--alfresco-primary)' }}></i>
              <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
                Alfresco Data Transformer
              </h1>
            </div>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
              Sign in to access the migration dashboard
            </p>
          </div>

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label htmlFor="username" className="block text-sm font-semibold mb-2">
                Username
              </Label>
              <Input
                id="username"
                data-testid="input-username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your username"
                className="w-full"
                required
              />
            </div>

            <div>
              <Label htmlFor="password" className="block text-sm font-semibold mb-2">
                Password
              </Label>
              <Input
                id="password"
                data-testid="input-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                className="w-full"
                required
              />
            </div>

            <Button
              type="submit"
              data-testid="button-login"
              className="w-full py-3 text-white font-medium text-lg"
              style={{ background: 'var(--alfresco-primary)' }}
            >
              <i className="fas fa-sign-in-alt mr-2"></i>
              Sign In
            </Button>
          </form>

          {/* Default Credentials */}
          <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <p className="text-sm font-semibold text-blue-800 mb-2">Default Admin Credentials:</p>
            <p className="text-sm text-blue-700">Username: <code>admin</code></p>
            <p className="text-sm text-blue-700">Password: <code>admin</code></p>
          </div>

          {/* Signup Link */}
          <div className="mt-6 text-center">
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
              Don't have an account?{' '}
              <Link href="/signup">
                <span className="font-semibold hover:underline" style={{ color: 'var(--alfresco-primary)' }}>
                  Sign up
                </span>
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}