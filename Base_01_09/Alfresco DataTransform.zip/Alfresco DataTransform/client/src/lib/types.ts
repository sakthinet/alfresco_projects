export interface NavigationItem {
  id: string;
  label: string;
  icon: string;
  path: string;
}

export interface StatsData {
  total: number;
  migrated: number;
  remaining: number;
  progress: number;
}

export interface SystemStatus {
  status: 'connected' | 'disconnected' | 'error';
  url: string;
  lastSync?: string;
}

export type Theme = 'light' | 'dark' | 'custom' | 'hyland';

export interface AppState {
  theme: Theme;
  sidebarCollapsed: boolean;
  activeNav: string;
}

export interface ConfigurationTab {
  id: string;
  label: string;
  content: React.ReactNode;
}
