import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

// Simple in-memory session storage (for skeleton)
const sessions = new Map<string, any>();

export async function registerRoutes(app: Express): Promise<Server> {
  // Simple hardcoded authentication routes
  app.post('/api/auth/login', async (req, res) => {
    try {
      const { username, password } = req.body;
      
      // Hardcoded admin credentials
      if (username === 'admin' && password === 'admin') {
        const sessionToken = 'simple-session-' + Date.now();
        const user = {
          id: '1',
          username: 'admin',
          email: 'admin@alfresco.com',
          role: 'admin',
          createdAt: new Date(),
          updatedAt: new Date(),
        };
        
        // Store session
        sessions.set(sessionToken, user);
        
        // Set cookie
        res.cookie('auth-token', sessionToken, { 
          httpOnly: true, 
          maxAge: 24 * 60 * 60 * 1000 // 24 hours
        });
        
        res.json({ user, success: true });
      } else {
        res.status(401).json({ error: 'Invalid credentials', success: false });
      }
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ error: 'Internal server error', success: false });
    }
  });

  app.post('/api/auth/signup', async (req, res) => {
    try {
      const { username, password, email } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ error: 'Username and password required', success: false });
      }
      
      const sessionToken = 'simple-session-' + Date.now();
      const user = {
        id: Date.now().toString(),
        username,
        email: email || null,
        role: 'user',
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      // Store session
      sessions.set(sessionToken, user);
      
      // Set cookie
      res.cookie('auth-token', sessionToken, { 
        httpOnly: true, 
        maxAge: 24 * 60 * 60 * 1000 // 24 hours
      });
      
      res.json({ user, success: true });
    } catch (error) {
      console.error('Signup error:', error);
      res.status(500).json({ error: 'Internal server error', success: false });
    }
  });

  app.post('/api/auth/logout', (req, res) => {
    const token = req.cookies['auth-token'];
    if (token) {
      sessions.delete(token);
    }
    res.clearCookie('auth-token');
    res.json({ success: true });
  });

  app.get('/api/auth/me', async (req, res) => {
    const token = req.cookies['auth-token'];
    const user = token ? sessions.get(token) : null;
    
    if (user) {
      res.json({ user, success: true });
    } else {
      res.status(401).json({ error: 'Not authenticated', success: false });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
