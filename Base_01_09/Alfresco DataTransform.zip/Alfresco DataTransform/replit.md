# Overview

This is an Alfresco Data Transformer application built as a full-stack web application for managing document migration between Alfresco systems. The application provides a comprehensive dashboard for monitoring migration progress, configuring source and target systems, generating reports, and managing migration templates. It features a modern React frontend with a professional UI design system and an Express.js backend with PostgreSQL database integration.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **Routing**: Wouter for lightweight client-side routing
- **UI Framework**: Radix UI components with shadcn/ui design system
- **Styling**: Tailwind CSS with CSS variables for theming support
- **State Management**: TanStack Query (React Query) for server state management
- **Form Handling**: React Hook Form with Zod validation through @hookform/resolvers

## Backend Architecture  
- **Framework**: Express.js with TypeScript using ES modules
- **Development Setup**: tsx for TypeScript execution in development
- **Build Process**: esbuild for production bundling with platform-specific optimizations
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Data Storage**: Dual storage implementation with in-memory storage for development and PostgreSQL for production

## Component Architecture
- **Layout System**: Collapsible sidebar navigation with responsive design
- **Theme System**: Multiple theme support (light, dark, custom, Hyland Alfresco) with CSS custom properties
- **Page Structure**: Route-based pages for Home dashboard, Configurations, Reports, Migration control, and Templates
- **UI Components**: Comprehensive component library built on Radix primitives

## Data Layer
- **Database Schema**: PostgreSQL with users table containing id, username, and password fields
- **Migration System**: Drizzle migrations stored in `/migrations` directory
- **Type Safety**: Full TypeScript integration with inferred types from database schema
- **Validation**: Zod schemas for runtime validation integrated with Drizzle

## Development Features
- **Hot Module Replacement**: Vite HMR with custom error overlay for development
- **Path Aliases**: Configured aliases for clean imports (@/, @shared/, @assets/)
- **Development Tools**: Replit integration with cartographer plugin and runtime error modal
- **Static Assets**: Support for attached assets and proper asset resolution

## Authentication & Security
- **Session Management**: PostgreSQL-based session storage using connect-pg-simple
- **User Management**: Basic user creation and retrieval with username/password authentication
- **Type-Safe API**: Shared schema definitions between frontend and backend

# External Dependencies

## Database & ORM
- **@neondatabase/serverless**: Neon PostgreSQL serverless driver for database connectivity
- **drizzle-orm**: Modern TypeScript ORM with full type safety
- **drizzle-kit**: Database migration and schema management tooling
- **connect-pg-simple**: PostgreSQL session store for Express sessions

## UI & Design System
- **@radix-ui/***: Complete set of unstyled, accessible UI primitives
- **tailwindcss**: Utility-first CSS framework with custom configuration
- **class-variance-authority**: Component variant API for consistent styling
- **clsx & tailwind-merge**: Conditional class name utilities

## Development & Build Tools
- **vite**: Fast build tool and development server
- **@vitejs/plugin-react**: React support for Vite
- **esbuild**: Fast JavaScript bundler for production builds
- **tsx**: TypeScript execution for Node.js development

## Data Management
- **@tanstack/react-query**: Server state management and caching
- **react-hook-form**: Performant forms with minimal re-renders
- **zod**: TypeScript-first schema validation
- **date-fns**: Modern JavaScript date utility library

## UI Enhancement Libraries
- **wouter**: Minimalist routing for React applications
- **cmdk**: Command menu component for better UX
- **embla-carousel-react**: Touch-friendly carousel component
- **lucide-react**: Beautiful & consistent icon library

## Replit Integration
- **@replit/vite-plugin-runtime-error-modal**: Development error overlay
- **@replit/vite-plugin-cartographer**: Replit-specific development enhancements