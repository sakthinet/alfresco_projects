import { BarChart3 } from "lucide-react";

export default function Reports() {
  return (
    <div className="text-center py-20">
      <BarChart3 className="mx-auto text-6xl text-muted-foreground mb-6" size={96} />
      <h2 className="text-2xl font-semibold text-muted-foreground mb-4">
        Reports Module
      </h2>
      <p className="text-muted-foreground">
        This section will be implemented in future iterations.
      </p>
    </div>
  );
}
