import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider, useTheme } from "@/components/layout/ThemeProvider";
import { Sidebar } from "@/components/layout/Sidebar";
import { useSidebar } from "@/hooks/use-sidebar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

import Home from "@/pages/Home";
import Configurations from "@/pages/Configurations";
import Reports from "@/pages/Reports";
import Migration from "@/pages/Migration";
import Templates from "@/pages/Templates";
import NotFound from "@/pages/not-found";

function ThemeSwitcher() {
  const { theme, setTheme } = useTheme();

  const themes = [
    { id: "default", label: "Light" },
    { id: "dark", label: "Dark" },
    { id: "hyland", label: "Hyland Alfresco" }
  ];

  return (
    <div className="fixed top-5 right-5 z-40">
      <Select value={theme} onValueChange={setTheme}>
        <SelectTrigger className="w-40 bg-card border-border shadow-lg">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {themes.map((themeOption) => (
            <SelectItem key={themeOption.id} value={themeOption.id}>
              {themeOption.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/configurations" component={Configurations} />
      <Route path="/reports" component={Reports} />
      <Route path="/migration" component={Migration} />
      <Route path="/templates" component={Templates} />
      <Route component={NotFound} />
    </Switch>
  );
}

function MainLayout() {
  const { isCollapsed, isMobile, toggleSidebar } = useSidebar();

  return (
    <div className="min-h-screen transition-all duration-300 bg-background">
      <Sidebar isCollapsed={isCollapsed} onToggle={toggleSidebar} />
      <ThemeSwitcher />

      {/* Main Content */}
      <main className={cn(
        "transition-all duration-300 min-h-screen",
        isCollapsed ? "ml-[70px]" : "ml-[250px]",
        isMobile && "ml-0"
      )}>
        <div className="p-6 lg:p-8">
          <Router />
        </div>
      </main>

      {/* Footer */}
      <footer className={cn(
        "text-center py-5 text-sm text-muted-foreground border-t border-border transition-all duration-300 main-footer",
        isCollapsed ? "ml-[70px]" : "ml-[250px]",
        isMobile && "ml-0"
      )}>
        <div className="px-6">
          <p>&copy; 2024 Alfresco Migration Tool. Built with React + TypeScript.</p>
          <p className="text-xs mt-1 opacity-75">
            Enterprise Document Migration Solution
          </p>
        </div>
      </footer>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="default" storageKey="alfresco-ui-theme">
        <TooltipProvider>
          <Toaster />
          <MainLayout />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
