import { Server, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

interface SystemStatusCardProps {
  title: string;
  status: string;
  url: string;
  onTest: () => void;
}

export function SystemStatusCard({ title, status, url, onTest }: SystemStatusCardProps) {
  return (
    <div className="bg-card dark:bg-card rounded-2xl p-6 shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 border border-border">
      <h3 className="text-xl font-semibold mb-4 text-card-foreground">
        <Server className="inline mr-2 text-primary" size={20} />
        {title}
      </h3>
      <div className="text-muted-foreground text-sm mb-4">
        {url}
      </div>
      <div className="flex items-center justify-between">
        <span className="inline-flex items-center gap-2 bg-gradient-to-r from-green-500 to-green-600 text-white px-4 py-2 rounded-full text-sm font-medium">
          <CheckCircle size={16} />
          {status}
        </span>
        <Button
          onClick={onTest}
          variant="outline"
          className="border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground"
        >
          Test Connection
        </Button>
      </div>
    </div>
  );
}
