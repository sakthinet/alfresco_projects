import { FileText, CheckCircle, Clock, TrendingUp, Gauge, Network } from "lucide-react";
import { StatsCard } from "./StatsCard";
import { SystemStatusCard } from "./SystemStatusCard";

const statsData = [
  { title: "Total Documents", value: "12,847", icon: FileText, gradient: "stats-card-gradient" },
  { title: "Migrated", value: "8,521", icon: CheckCircle, gradient: "stats-card-migrated" },
  { title: "Remaining", value: "4,326", icon: Clock, gradient: "stats-card-remaining" },
  { title: "Success Rate", value: "98.2%", icon: TrendingUp, gradient: "stats-card-progress" }
];

const systemData = [
  { title: "Alfresco ECM", status: "Connected", url: "https://alfresco.company.com:8080" },
  { title: "Apache Airflow", status: "Connected", url: "https://airflow.company.com:8080" }
];

export function Dashboard() {
  const handleTestConnection = (system: string) => {
    console.log(`Testing connection for ${system}`);
    // TODO: Implement actual connection testing logic
  };

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="flex items-center gap-4 mb-8">
        <Gauge className="text-3xl text-primary" size={32} />
        <h1 className="text-3xl font-bold text-foreground">Dashboard Overview</h1>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statsData.map((stat, index) => (
          <StatsCard
            key={index}
            title={stat.title}
            value={stat.value}
            icon={stat.icon}
            gradient={stat.gradient}
            delay={index * 100}
          />
        ))}
      </div>

      {/* System Status */}
      <div className="mt-12">
        <h2 className="text-2xl font-bold text-foreground mb-6">
          <Network className="inline mr-3 text-primary" size={24} />
          System Status
        </h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {systemData.map((system, index) => (
            <SystemStatusCard
              key={index}
              title={system.title}
              status={system.status}
              url={system.url}
              onTest={() => handleTestConnection(system.title)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
