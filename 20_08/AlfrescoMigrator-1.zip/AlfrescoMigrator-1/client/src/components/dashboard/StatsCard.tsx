import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: string;
  icon: LucideIcon;
  gradient?: string;
  delay?: number;
}

export function StatsCard({ 
  title, 
  value, 
  icon: Icon, 
  gradient = "stats-card-gradient", 
  delay = 0 
}: StatsCardProps) {
  return (
    <div 
      className={cn(
        gradient,
        "rounded-2xl p-8 text-white shadow-xl hover:shadow-2xl transform hover:-translate-y-2 transition-all duration-300 min-h-[160px] flex flex-col justify-center text-center relative overflow-hidden fade-in"
      )}
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="relative z-10">
        <div 
          className="text-5xl font-bold mb-2 slide-fade-in" 
          style={{ animationDelay: `${delay + 200}ms` }}
        >
          {value}
        </div>
        <div className="text-lg opacity-90">
          <Icon className="inline mr-2" size={20} />
          {title}
        </div>
      </div>
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-5 transform -skew-x-12"></div>
    </div>
  );
}
