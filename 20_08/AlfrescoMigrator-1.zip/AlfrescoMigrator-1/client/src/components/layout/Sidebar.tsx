import { Link, useLocation } from "wouter";
import { Database, Home, Settings, BarChart3, Puzzle, FileText, ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { useTheme } from "./ThemeProvider";

interface SidebarProps {
  isCollapsed: boolean;
  onToggle: () => void;
}

const navigationItems = [
  { id: "home", label: "Home", icon: Home, path: "/" },
  { id: "configurations", label: "Configurations", icon: Settings, path: "/configurations" },
  { id: "reports", label: "Reports", icon: BarChart3, path: "/reports" },
  { id: "migration", label: "Migration", icon: Puzzle, path: "/migration" },
  { id: "templates", label: "Templates", icon: FileText, path: "/templates" },
];

export function Sidebar({ isCollapsed, onToggle }: SidebarProps) {
  const [location] = useLocation();
  const { theme } = useTheme();

  console.log('Current theme:', theme); // Debug log

  return (
    <div 
      className={cn(
        "fixed top-0 left-0 h-screen text-white transition-all duration-300 z-50 shadow-2xl",
        isCollapsed ? "w-[70px]" : "w-[250px]",
        // Force different gradients based on theme
        theme === 'hyland' && "bg-gradient-to-br from-blue-900 to-blue-800",
        theme === 'dark' && "bg-gradient-to-br from-indigo-500 to-indigo-600", 
        (theme === 'default' || !theme) && "bg-gradient-to-br from-indigo-500 to-indigo-600"
      )}
      style={{
        background: theme === 'hyland' 
          ? 'linear-gradient(to bottom right, #0061A0, #004578)' 
          : 'linear-gradient(to bottom right, #6366f1, #4f46e5)'
      }}
    >
      {/* Header */}
      <div className="flex items-center gap-3 p-4 border-b border-white border-opacity-10">
        <Database className="text-2xl flex-shrink-0" size={28} />
        <h1 className={cn(
          "text-xl font-semibold transition-opacity duration-300 whitespace-nowrap",
          isCollapsed ? "opacity-0" : "opacity-100"
        )}>
          Alfresco Migration
        </h1>
      </div>

      {/* Navigation */}
      <nav className="py-4">
        {navigationItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path;
          
          return (
            <div key={item.id} className="my-2">
              <Link href={item.path}>
                <button className={cn(
                  "w-full flex items-center px-4 py-3 text-white text-opacity-80 hover:text-white hover:bg-white hover:bg-opacity-10 transition-all duration-300",
                  isActive && "bg-white bg-opacity-20 text-white border-r-4 border-white"
                )}>
                  <Icon className="w-5 h-5 text-center mr-3 flex-shrink-0" />
                  <span className={cn(
                    "transition-opacity duration-300 whitespace-nowrap",
                    isCollapsed ? "opacity-0" : "opacity-100"
                  )}>
                    {item.label}
                  </span>
                </button>
              </Link>
            </div>
          );
        })}
      </nav>

      {/* Toggle Button */}
      <button
        onClick={onToggle}
        className="absolute -right-4 top-4 w-8 h-8 bg-primary text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center"
      >
        {isCollapsed ? (
          <ChevronRight className="w-4 h-4" />
        ) : (
          <ChevronLeft className="w-4 h-4" />
        )}
      </button>
    </div>
  );
}
