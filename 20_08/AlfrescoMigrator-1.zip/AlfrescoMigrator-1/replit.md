# Alfresco Migration Application

## Overview

This is a full-stack web application built for managing Alfresco ECM system migrations. The application provides a comprehensive dashboard interface for monitoring migration progress, managing configurations, generating reports, and handling migration templates. It features a modern React frontend with shadcn/ui components and an Express.js backend with PostgreSQL database integration.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **Theme System**: Custom theme provider supporting multiple themes (default, dark, custom, hyland)

### Backend Architecture  
- **Framework**: Express.js with TypeScript
- **Build System**: ESBuild for production builds, tsx for development
- **Storage Interface**: Abstracted storage layer with in-memory implementation (MemStorage)
- **Development Server**: Vite integration for hot module replacement in development
- **API Structure**: RESTful API with `/api` prefix for all endpoints

### Data Storage Solutions
- **Database**: PostgreSQL with Neon serverless driver
- **ORM**: Drizzle ORM with TypeScript schema definitions
- **Migrations**: Drizzle Kit for database schema management
- **Schema Location**: Shared schema definitions in `/shared/schema.ts`
- **Session Storage**: PostgreSQL sessions using connect-pg-simple

### Component Structure
- **Layout Components**: Responsive sidebar navigation with collapse functionality
- **Dashboard Components**: Modular dashboard with stats cards and system status monitoring
- **UI Components**: Comprehensive shadcn/ui component library
- **Page Structure**: Route-based page components (Home, Configurations, Reports, Migration, Templates)

### Development Setup
- **Monorepo Structure**: Client and server code in separate directories with shared types
- **Path Aliases**: TypeScript path mapping for clean imports (`@/`, `@shared/`)
- **Hot Reload**: Vite development server with runtime error overlays
- **Type Safety**: Strict TypeScript configuration across client and server

## Development URLs

When running the development server with `npm run dev`, the application will be available at:

- **📍 Local Access**: `http://localhost:5000`
  - Use this URL when accessing from the same machine
- **🌐 Network Access**: `http://[YOUR_IP]:5000`
  - The actual network IP will be displayed in the console when starting the dev server
  - Use this URL to access from other devices on the same network
- **🔗 API Endpoints**: `http://localhost:5000/api`
  - All backend API endpoints are prefixed with `/api`

### Quick Commands
```bash
npm run dev        # Start development server with full URL info
npm run dev:info   # Display URL information without starting server
```

The development server will automatically display all available URLs with a beautiful formatted output when started.

### Authentication & Authorization
- **Session Management**: Express sessions with PostgreSQL store
- **User Schema**: Basic user model with username/password authentication
- **Storage Interface**: User CRUD operations abstracted through IStorage interface

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Neon PostgreSQL serverless driver for database connectivity
- **drizzle-orm**: Type-safe ORM for database operations
- **drizzle-zod**: Schema validation integration between Drizzle and Zod

### UI & Styling
- **@radix-ui/***: Comprehensive set of unstyled UI primitives for accessibility
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe variant API for component styling
- **lucide-react**: Icon library for consistent iconography

### State Management & Data Fetching
- **@tanstack/react-query**: Server state management and caching
- **@hookform/resolvers**: Form validation resolver integration
- **react-hook-form**: Form state management and validation

### Development Tools
- **vite**: Build tool and development server
- **@replit/vite-plugin-runtime-error-modal**: Development error handling
- **@replit/vite-plugin-cartographer**: Replit-specific development tooling
- **tsx**: TypeScript execution for Node.js development

### Database & Sessions
- **connect-pg-simple**: PostgreSQL session store for Express sessions
- **pg**: PostgreSQL client library

### Additional Libraries
- **date-fns**: Date manipulation and formatting
- **embla-carousel-react**: Carousel component functionality
- **cmdk**: Command palette interface components
- **wouter**: Lightweight client-side routing