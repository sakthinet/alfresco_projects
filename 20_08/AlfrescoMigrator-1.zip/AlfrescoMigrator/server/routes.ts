import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMigrationJobSchema, insertDataSourceFileSchema, insertFieldMappingSchema, insertAlfrescoConfigSchema, insertMigrationLogSchema } from "@shared/schema";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";

const upload = multer({ 
  dest: 'uploads/',
  limits: {
    fileSize: 100 * 1024 * 1024 // 100MB limit
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Migration Jobs
  app.get("/api/migration-jobs", async (req, res) => {
    try {
      const jobs = await storage.getMigrationJobs();
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch migration jobs" });
    }
  });

  app.get("/api/migration-jobs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const job = await storage.getMigrationJob(id);
      if (!job) {
        return res.status(404).json({ message: "Migration job not found" });
      }
      res.json(job);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch migration job" });
    }
  });

  app.post("/api/migration-jobs", async (req, res) => {
    try {
      const validatedData = insertMigrationJobSchema.parse(req.body);
      const job = await storage.createMigrationJob(validatedData);
      res.status(201).json(job);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create migration job" });
    }
  });

  app.patch("/api/migration-jobs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const job = await storage.updateMigrationJob(id, req.body);
      if (!job) {
        return res.status(404).json({ message: "Migration job not found" });
      }
      res.json(job);
    } catch (error) {
      res.status(500).json({ message: "Failed to update migration job" });
    }
  });

  app.delete("/api/migration-jobs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteMigrationJob(id);
      if (!deleted) {
        return res.status(404).json({ message: "Migration job not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete migration job" });
    }
  });

  // File Upload
  app.post("/api/migration-jobs/:id/files", upload.array('files'), async (req, res) => {
    try {
      const jobId = parseInt(req.params.id);
      const files = req.files as Express.Multer.File[];
      
      if (!files || files.length === 0) {
        return res.status(400).json({ message: "No files uploaded" });
      }

      const uploadedFiles = [];
      for (const file of files) {
        const fileData = {
          jobId,
          filename: file.filename,
          originalName: file.originalname,
          fileSize: file.size,
          mimeType: file.mimetype,
        };
        
        const savedFile = await storage.createDataSourceFile(fileData);
        uploadedFiles.push(savedFile);
      }

      res.status(201).json(uploadedFiles);
    } catch (error) {
      res.status(500).json({ message: "Failed to upload files" });
    }
  });

  app.get("/api/migration-jobs/:id/files", async (req, res) => {
    try {
      const jobId = parseInt(req.params.id);
      const files = await storage.getJobFiles(jobId);
      res.json(files);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch files" });
    }
  });

  // Field Mappings
  app.get("/api/migration-jobs/:id/mappings", async (req, res) => {
    try {
      const jobId = parseInt(req.params.id);
      const mappings = await storage.getJobFieldMappings(jobId);
      res.json(mappings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch field mappings" });
    }
  });

  app.post("/api/migration-jobs/:id/mappings", async (req, res) => {
    try {
      const jobId = parseInt(req.params.id);
      const validatedData = insertFieldMappingSchema.parse({ ...req.body, jobId });
      const mapping = await storage.createFieldMapping(validatedData);
      res.status(201).json(mapping);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create field mapping" });
    }
  });

  app.patch("/api/migration-jobs/:jobId/mappings/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const mapping = await storage.updateFieldMapping(id, req.body);
      if (!mapping) {
        return res.status(404).json({ message: "Field mapping not found" });
      }
      res.json(mapping);
    } catch (error) {
      res.status(500).json({ message: "Failed to update field mapping" });
    }
  });

  // Alfresco Config
  app.get("/api/migration-jobs/:id/alfresco-config", async (req, res) => {
    try {
      const jobId = parseInt(req.params.id);
      const config = await storage.getJobAlfrescoConfig(jobId);
      if (!config) {
        return res.status(404).json({ message: "Alfresco config not found" });
      }
      res.json(config);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch Alfresco config" });
    }
  });

  app.post("/api/migration-jobs/:id/alfresco-config", async (req, res) => {
    try {
      const jobId = parseInt(req.params.id);
      const validatedData = insertAlfrescoConfigSchema.parse({ ...req.body, jobId });
      const config = await storage.createAlfrescoConfig(validatedData);
      res.status(201).json(config);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create Alfresco config" });
    }
  });

  // Migration Logs
  app.get("/api/migration-jobs/:id/logs", async (req, res) => {
    try {
      const jobId = parseInt(req.params.id);
      const logs = await storage.getJobLogs(jobId);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch migration logs" });
    }
  });

  app.post("/api/migration-jobs/:id/logs", async (req, res) => {
    try {
      const jobId = parseInt(req.params.id);
      const validatedData = insertMigrationLogSchema.parse({ ...req.body, jobId });
      const log = await storage.createMigrationLog(validatedData);
      res.status(201).json(log);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create migration log" });
    }
  });

  // Start Migration
  app.post("/api/migration-jobs/:id/start", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const job = await storage.updateMigrationJob(id, { status: "running" });
      if (!job) {
        return res.status(404).json({ message: "Migration job not found" });
      }

      // Log the start of migration
      await storage.createMigrationLog({
        jobId: id,
        level: "info",
        message: "Migration started",
        details: { startTime: new Date().toISOString() }
      });

      res.json({ message: "Migration started", job });
    } catch (error) {
      res.status(500).json({ message: "Failed to start migration" });
    }
  });

  // Get Migration Statistics
  app.get("/api/migration-stats", async (req, res) => {
    try {
      const jobs = await storage.getMigrationJobs();
      const stats = {
        totalMigrations: jobs.length,
        activeJobs: jobs.filter(job => job.status === "running").length,
        completedToday: jobs.filter(job => {
          const today = new Date();
          const jobDate = new Date(job.updatedAt);
          return job.status === "completed" && 
                 jobDate.toDateString() === today.toDateString();
        }).length,
      };
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch migration statistics" });
    }
  });

  // Parse CSV/Excel for preview
  app.post("/api/parse-file", upload.single('file'), async (req, res) => {
    try {
      const file = req.file;
      if (!file) {
        return res.status(400).json({ message: "No file provided" });
      }

      // This is a simplified parser - in a real implementation you'd use libraries like csv-parser, xlsx, etc.
      const filePath = file.path;
      const extension = path.extname(file.originalname).toLowerCase();
      
      let preview = {
        headers: [],
        rows: [],
        totalRows: 0,
        validationResults: {
          valid: true,
          errors: [],
          warnings: []
        }
      };

      if (extension === '.csv') {
        // Simulate CSV parsing
        preview = {
          headers: ["Document ID", "Title", "Author", "Created Date"],
          rows: [
            ["DOC001", "Annual Report 2023", "John Smith", "2023-01-15"],
            ["DOC002", "Policy Document", "Jane Doe", "2023-02-20"],
            ["DOC003", "Meeting Minutes", "Mike Johnson", "2023-03-10"]
          ],
          totalRows: 147,
          validationResults: {
            valid: true,
            errors: [],
            warnings: []
          }
        };
      }

      // Clean up uploaded file
      fs.unlinkSync(filePath);

      res.json(preview);
    } catch (error) {
      res.status(500).json({ message: "Failed to parse file" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
