import { 
  migrationJobs, 
  dataSourceFiles, 
  fieldMappings, 
  alfrescoConfigs, 
  migrationLogs,
  type MigrationJob, 
  type InsertMigrationJob,
  type DataSourceFile,
  type InsertDataSourceFile,
  type FieldMapping,
  type InsertFieldMapping,
  type AlfrescoConfig,
  type InsertAlfrescoConfig,
  type MigrationLog,
  type InsertMigrationLog
} from "@shared/schema";

export interface IStorage {
  // Migration Jobs
  getMigrationJobs(): Promise<MigrationJob[]>;
  getMigrationJob(id: number): Promise<MigrationJob | undefined>;
  createMigrationJob(job: InsertMigrationJob): Promise<MigrationJob>;
  updateMigrationJob(id: number, updates: Partial<MigrationJob>): Promise<MigrationJob | undefined>;
  deleteMigrationJob(id: number): Promise<boolean>;

  // Data Source Files
  getJobFiles(jobId: number): Promise<DataSourceFile[]>;
  createDataSourceFile(file: InsertDataSourceFile): Promise<DataSourceFile>;
  deleteDataSourceFile(id: number): Promise<boolean>;

  // Field Mappings
  getJobFieldMappings(jobId: number): Promise<FieldMapping[]>;
  createFieldMapping(mapping: InsertFieldMapping): Promise<FieldMapping>;
  updateFieldMapping(id: number, updates: Partial<FieldMapping>): Promise<FieldMapping | undefined>;
  deleteFieldMapping(id: number): Promise<boolean>;

  // Alfresco Configs
  getJobAlfrescoConfig(jobId: number): Promise<AlfrescoConfig | undefined>;
  createAlfrescoConfig(config: InsertAlfrescoConfig): Promise<AlfrescoConfig>;
  updateAlfrescoConfig(id: number, updates: Partial<AlfrescoConfig>): Promise<AlfrescoConfig | undefined>;

  // Migration Logs
  getJobLogs(jobId: number): Promise<MigrationLog[]>;
  createMigrationLog(log: InsertMigrationLog): Promise<MigrationLog>;
}

export class MemStorage implements IStorage {
  private migrationJobs: Map<number, MigrationJob>;
  private dataSourceFiles: Map<number, DataSourceFile>;
  private fieldMappings: Map<number, FieldMapping>;
  private alfrescoConfigs: Map<number, AlfrescoConfig>;
  private migrationLogs: Map<number, MigrationLog>;
  private currentJobId: number;
  private currentFileId: number;
  private currentMappingId: number;
  private currentConfigId: number;
  private currentLogId: number;

  constructor() {
    this.migrationJobs = new Map();
    this.dataSourceFiles = new Map();
    this.fieldMappings = new Map();
    this.alfrescoConfigs = new Map();
    this.migrationLogs = new Map();
    this.currentJobId = 1;
    this.currentFileId = 1;
    this.currentMappingId = 1;
    this.currentConfigId = 1;
    this.currentLogId = 1;
  }

  // Migration Jobs
  async getMigrationJobs(): Promise<MigrationJob[]> {
    return Array.from(this.migrationJobs.values());
  }

  async getMigrationJob(id: number): Promise<MigrationJob | undefined> {
    return this.migrationJobs.get(id);
  }

  async createMigrationJob(insertJob: InsertMigrationJob): Promise<MigrationJob> {
    const id = this.currentJobId++;
    const now = new Date();
    const job: MigrationJob = {
      ...insertJob,
      id,
      createdAt: now,
      updatedAt: now,
      totalRecords: insertJob.totalRecords || 0,
      processedRecords: insertJob.processedRecords || 0,
      errorCount: insertJob.errorCount || 0,
    };
    this.migrationJobs.set(id, job);
    return job;
  }

  async updateMigrationJob(id: number, updates: Partial<MigrationJob>): Promise<MigrationJob | undefined> {
    const job = this.migrationJobs.get(id);
    if (!job) return undefined;
    
    const updatedJob = { ...job, ...updates, updatedAt: new Date() };
    this.migrationJobs.set(id, updatedJob);
    return updatedJob;
  }

  async deleteMigrationJob(id: number): Promise<boolean> {
    return this.migrationJobs.delete(id);
  }

  // Data Source Files
  async getJobFiles(jobId: number): Promise<DataSourceFile[]> {
    return Array.from(this.dataSourceFiles.values()).filter(file => file.jobId === jobId);
  }

  async createDataSourceFile(insertFile: InsertDataSourceFile): Promise<DataSourceFile> {
    const id = this.currentFileId++;
    const file: DataSourceFile = {
      ...insertFile,
      id,
      uploadedAt: new Date(),
    };
    this.dataSourceFiles.set(id, file);
    return file;
  }

  async deleteDataSourceFile(id: number): Promise<boolean> {
    return this.dataSourceFiles.delete(id);
  }

  // Field Mappings
  async getJobFieldMappings(jobId: number): Promise<FieldMapping[]> {
    return Array.from(this.fieldMappings.values()).filter(mapping => mapping.jobId === jobId);
  }

  async createFieldMapping(insertMapping: InsertFieldMapping): Promise<FieldMapping> {
    const id = this.currentMappingId++;
    const mapping: FieldMapping = {
      ...insertMapping,
      id,
      isRequired: insertMapping.isRequired || false,
    };
    this.fieldMappings.set(id, mapping);
    return mapping;
  }

  async updateFieldMapping(id: number, updates: Partial<FieldMapping>): Promise<FieldMapping | undefined> {
    const mapping = this.fieldMappings.get(id);
    if (!mapping) return undefined;
    
    const updatedMapping = { ...mapping, ...updates };
    this.fieldMappings.set(id, updatedMapping);
    return updatedMapping;
  }

  async deleteFieldMapping(id: number): Promise<boolean> {
    return this.fieldMappings.delete(id);
  }

  // Alfresco Configs
  async getJobAlfrescoConfig(jobId: number): Promise<AlfrescoConfig | undefined> {
    return Array.from(this.alfrescoConfigs.values()).find(config => config.jobId === jobId);
  }

  async createAlfrescoConfig(insertConfig: InsertAlfrescoConfig): Promise<AlfrescoConfig> {
    const id = this.currentConfigId++;
    const config: AlfrescoConfig = {
      ...insertConfig,
      id,
      createFolderStructure: insertConfig.createFolderStructure !== false,
    };
    this.alfrescoConfigs.set(id, config);
    return config;
  }

  async updateAlfrescoConfig(id: number, updates: Partial<AlfrescoConfig>): Promise<AlfrescoConfig | undefined> {
    const config = this.alfrescoConfigs.get(id);
    if (!config) return undefined;
    
    const updatedConfig = { ...config, ...updates };
    this.alfrescoConfigs.set(id, updatedConfig);
    return updatedConfig;
  }

  // Migration Logs
  async getJobLogs(jobId: number): Promise<MigrationLog[]> {
    return Array.from(this.migrationLogs.values()).filter(log => log.jobId === jobId);
  }

  async createMigrationLog(insertLog: InsertMigrationLog): Promise<MigrationLog> {
    const id = this.currentLogId++;
    const log: MigrationLog = {
      ...insertLog,
      id,
      timestamp: new Date(),
    };
    this.migrationLogs.set(id, log);
    return log;
  }
}

export const storage = new MemStorage();
