import { pgTable, text, serial, integer, boolean, json, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const migrationJobs = pgTable("migration_jobs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  sourceType: text("source_type").notNull(), // csv, xml, xlsx, json, database, filesystem
  status: text("status").notNull().default("pending"), // pending, running, completed, failed
  configuration: json("configuration").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  totalRecords: integer("total_records").default(0),
  processedRecords: integer("processed_records").default(0),
  errorCount: integer("error_count").default(0),
});

export const dataSourceFiles = pgTable("data_source_files", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").references(() => migrationJobs.id).notNull(),
  filename: text("filename").notNull(),
  originalName: text("original_name").notNull(),
  fileSize: integer("file_size").notNull(),
  mimeType: text("mime_type").notNull(),
  uploadedAt: timestamp("uploaded_at").defaultNow().notNull(),
});

export const fieldMappings = pgTable("field_mappings", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").references(() => migrationJobs.id).notNull(),
  sourceField: text("source_field").notNull(),
  targetField: text("target_field").notNull(),
  transformation: text("transformation"), // optional transformation rule
  isRequired: boolean("is_required").default(false),
});

export const alfrescoConfigs = pgTable("alfresco_configs", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").references(() => migrationJobs.id).notNull(),
  serverUrl: text("server_url").notNull(),
  username: text("username").notNull(),
  password: text("password").notNull(),
  repositoryId: text("repository_id").notNull(),
  targetPath: text("target_path").notNull(),
  createFolderStructure: boolean("create_folder_structure").default(true),
});

export const migrationLogs = pgTable("migration_logs", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").references(() => migrationJobs.id).notNull(),
  level: text("level").notNull(), // info, warning, error
  message: text("message").notNull(),
  details: json("details"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// Insert schemas
export const insertMigrationJobSchema = createInsertSchema(migrationJobs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDataSourceFileSchema = createInsertSchema(dataSourceFiles).omit({
  id: true,
  uploadedAt: true,
});

export const insertFieldMappingSchema = createInsertSchema(fieldMappings).omit({
  id: true,
});

export const insertAlfrescoConfigSchema = createInsertSchema(alfrescoConfigs).omit({
  id: true,
});

export const insertMigrationLogSchema = createInsertSchema(migrationLogs).omit({
  id: true,
  timestamp: true,
});

// Types
export type InsertMigrationJob = z.infer<typeof insertMigrationJobSchema>;
export type MigrationJob = typeof migrationJobs.$inferSelect;

export type InsertDataSourceFile = z.infer<typeof insertDataSourceFileSchema>;
export type DataSourceFile = typeof dataSourceFiles.$inferSelect;

export type InsertFieldMapping = z.infer<typeof insertFieldMappingSchema>;
export type FieldMapping = typeof fieldMappings.$inferSelect;

export type InsertAlfrescoConfig = z.infer<typeof insertAlfrescoConfigSchema>;
export type AlfrescoConfig = typeof alfrescoConfigs.$inferSelect;

export type InsertMigrationLog = z.infer<typeof insertMigrationLogSchema>;
export type MigrationLog = typeof migrationLogs.$inferSelect;

// Source type enum
export const sourceTypes = [
  "csv",
  "xml", 
  "xlsx",
  "json",
  "database",
  "filesystem"
] as const;

export type SourceType = typeof sourceTypes[number];

// Migration status enum
export const migrationStatuses = [
  "pending",
  "running", 
  "completed",
  "failed"
] as const;

export type MigrationStatus = typeof migrationStatuses[number];
