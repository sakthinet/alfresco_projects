import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, Database, Moon, Sun, Monitor, LogIn, UserPlus, User, Settings, LogOut, FileText, Activity } from "lucide-react";
import { cn } from "@/lib/utils";
import { useTheme } from "@/components/theme-provider";

interface HamburgerMenuProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
  stats?: {
    totalMigrations: number;
    activeJobs: number;
    completedToday: number;
  } | null;
  user?: {
    name: string;
    email: string;
    role: string;
  } | null;
  onLogin: () => void;
  onLogout: () => void;
}

export function HamburgerMenu({ currentTab, onTabChange, stats, user, onLogin, onLogout }: HamburgerMenuProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { theme, setTheme } = useTheme();

  const menuItems = [
    { id: "overview", label: "Overview", icon: Database },
    { id: "source-selection", label: "Source Selection", icon: Database },
    { id: "file-upload", label: "File Upload", icon: Database },
    { id: "data-mapping", label: "Data Mapping", icon: Database },
    { id: "alfresco-config", label: "Alfresco Config", icon: Database },
    { id: "migration", label: "Migration", icon: Database },
  ];

  const handleTabChange = (tabId: string) => {
    onTabChange(tabId);
    setIsOpen(false);
  };

  return (
    <>
      {/* Toggle Button for Mobile/Small Screens */}
      <Button 
        variant="ghost" 
        size="sm" 
        className="lg:hidden hover:bg-alfresco-blue/10 dark:hover:bg-alfresco-blue/20 transition-colors"
        onClick={() => setIsOpen(!isOpen)}
      >
        <Menu className="h-5 w-5 text-alfresco-blue" />
      </Button>
      
      {/* Overlay Background for Mobile */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-40 bg-black/20 backdrop-blur-sm lg:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}
      
      {/* Sidebar - Always visible on desktop, toggleable on mobile */}
      <div className={cn(
        "fixed left-0 top-0 z-50 h-full w-80 transform transition-transform duration-300 ease-in-out bg-gradient-to-b from-alfresco-light-blue to-white dark:from-gray-900 dark:to-card border-r border-alfresco-blue/20 shadow-2xl",
        "lg:translate-x-0", // Always visible on large screens
        isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0" // Toggle only on small screens
      )}>
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="p-6 border-b border-alfresco-blue/20 bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-alfresco-blue to-alfresco-teal rounded-xl flex items-center justify-center shadow-lg">
                <Database className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-foreground">Alfresco Migration</h1>
                <p className="text-sm text-alfresco-gray">Data Migration Utility</p>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex-1 p-6">
            <h2 className="text-sm font-medium text-foreground mb-4">Migration Steps</h2>
            <nav className="space-y-2">
              {menuItems.map((item, index) => (
                <Button
                  key={item.id}
                  variant="ghost"
                  className={cn(
                    "w-full justify-start p-4 h-auto transition-all duration-200 hover:scale-[1.02] group",
                    currentTab === item.id
                      ? "bg-gradient-to-r from-alfresco-blue to-alfresco-teal text-white shadow-lg border border-alfresco-blue/30"
                      : "text-foreground hover:bg-alfresco-light-blue/80 hover:text-alfresco-blue hover:shadow-md"
                  )}
                  onClick={() => handleTabChange(item.id)}
                >
                  <div className={cn(
                    "w-10 h-10 rounded-xl flex items-center justify-center mr-3 transition-all shadow-sm",
                    currentTab === item.id
                      ? "bg-white/20 text-white shadow-inner"
                      : "bg-alfresco-blue/10 text-alfresco-blue group-hover:bg-alfresco-blue/20"
                  )}>
                    <span className="text-sm font-bold">
                      {index + 1}
                    </span>
                  </div>
                  <div className="flex-1 text-left">
                    <span className="font-semibold text-sm block">{item.label}</span>
                    <span className={cn(
                      "text-xs",
                      currentTab === item.id ? "text-white/80" : "text-alfresco-gray"
                    )}>
                      Migration Step
                    </span>
                  </div>
                  {currentTab === item.id && (
                    <div className="w-2 h-2 bg-white rounded-full animate-pulse ml-2" />
                  )}
                </Button>
              ))}
            </nav>
          </div>

          {/* Theme Switcher */}
          <div className="p-6 border-t border-alfresco-blue/20">
            <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center">
              <div className="w-2 h-2 bg-alfresco-blue rounded-full mr-2"></div>
              Appearance
            </h3>
            <div className="space-y-2">
              <Button
                variant={theme === "light" ? "default" : "ghost"}
                size="sm"
                onClick={() => setTheme("light")}
                className={cn(
                  "w-full justify-start",
                  theme === "light" 
                    ? "bg-alfresco-blue text-white hover:bg-alfresco-blue/90" 
                    : "hover:bg-alfresco-light-blue/50 hover:text-alfresco-blue"
                )}
              >
                <Sun className="w-4 h-4 mr-3" />
                Light Mode
              </Button>
              <Button
                variant={theme === "dark" ? "default" : "ghost"}
                size="sm"
                onClick={() => setTheme("dark")}
                className={cn(
                  "w-full justify-start",
                  theme === "dark" 
                    ? "bg-alfresco-blue text-white hover:bg-alfresco-blue/90" 
                    : "hover:bg-alfresco-light-blue/50 hover:text-alfresco-blue"
                )}
              >
                <Moon className="w-4 h-4 mr-3" />
                Dark Mode
              </Button>
              <Button
                variant={theme === "system" ? "default" : "ghost"}
                size="sm"
                onClick={() => setTheme("system")}
                className={cn(
                  "w-full justify-start",
                  theme === "system" 
                    ? "bg-alfresco-blue text-white hover:bg-alfresco-blue/90" 
                    : "hover:bg-alfresco-light-blue/50 hover:text-alfresco-blue"
                )}
              >
                <Monitor className="w-4 h-4 mr-3" />
                System
              </Button>
            </div>
          </div>

          {/* User Section */}
          {user ? (
            <div className="p-6 border-t border-alfresco-blue/20 bg-gradient-to-b from-alfresco-light-blue/30 to-transparent">
              <div className="flex items-center space-x-3 mb-4 p-3 bg-white/60 dark:bg-gray-800/60 rounded-xl backdrop-blur-sm">
                <div className="w-12 h-12 bg-gradient-to-br from-alfresco-blue to-alfresco-teal rounded-xl flex items-center justify-center text-white font-bold shadow-lg">
                  {user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-foreground">{user.name}</p>
                  <p className="text-xs text-alfresco-gray">{user.email}</p>
                  <div className="flex items-center mt-1">
                    <Activity className="w-3 h-3 mr-1 text-alfresco-green" />
                    <span className="text-xs text-alfresco-green font-medium">Online</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2 mb-4">
                <Button variant="ghost" className="w-full justify-start hover:bg-alfresco-light-blue/50 hover:text-alfresco-blue" size="sm">
                  <User className="w-4 h-4 mr-3" />
                  Profile Settings
                </Button>
                <Button variant="ghost" className="w-full justify-start hover:bg-alfresco-light-blue/50 hover:text-alfresco-blue" size="sm">
                  <FileText className="w-4 h-4 mr-3" />
                  Migration History
                </Button>
                <Button variant="ghost" className="w-full justify-start hover:bg-alfresco-light-blue/50 hover:text-alfresco-blue" size="sm">
                  <Settings className="w-4 h-4 mr-3" />
                  Preferences
                </Button>
              </div>
              
              <Button 
                variant="outline" 
                className="w-full text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700 hover:border-red-300" 
                size="sm"
                onClick={() => {
                  onLogout();
                  setIsOpen(false);
                }}
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sign Out
              </Button>
            </div>
          ) : (
            <div className="p-6 border-t border-alfresco-blue/20 bg-gradient-to-b from-alfresco-light-blue/30 to-transparent">
              <div className="space-y-3">
                <Button 
                  className="w-full bg-gradient-to-r from-alfresco-blue to-alfresco-teal hover:from-alfresco-blue/90 hover:to-alfresco-teal/90 text-white shadow-lg" 
                  onClick={() => {
                    onLogin();
                    setIsOpen(false);
                  }}
                >
                  <LogIn className="w-4 h-4 mr-2" />
                  Sign In
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full border-alfresco-blue text-alfresco-blue hover:bg-alfresco-light-blue/50"
                  onClick={() => {
                    onLogin();
                    setIsOpen(false);
                  }}
                >
                  <UserPlus className="w-4 h-4 mr-2" />
                  Create Account
                </Button>
              </div>
            </div>
          )}

          {/* Migration Stats */}
          <div className="p-6 border-t border-alfresco-blue/20 bg-gradient-to-b from-alfresco-light-blue/20 to-transparent">
            <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center">
              <div className="w-2 h-2 bg-alfresco-green rounded-full mr-2"></div>
              Migration Stats
            </h3>
            <div className="space-y-4">
              <div className="bg-white/60 dark:bg-gray-800/60 p-3 rounded-xl backdrop-blur-sm">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-alfresco-gray">Total Migrations</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-alfresco-blue rounded-full"></div>
                    <span className="font-bold text-lg text-alfresco-blue">
                      {stats?.totalMigrations || 0}
                    </span>
                  </div>
                </div>
              </div>
              <div className="bg-white/60 dark:bg-gray-800/60 p-3 rounded-xl backdrop-blur-sm">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-alfresco-gray">Active Jobs</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-alfresco-orange rounded-full animate-pulse"></div>
                    <span className="font-bold text-lg text-alfresco-orange">
                      {stats?.activeJobs || 0}
                    </span>
                  </div>
                </div>
              </div>
              <div className="bg-white/60 dark:bg-gray-800/60 p-3 rounded-xl backdrop-blur-sm">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-alfresco-gray">Completed Today</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-alfresco-green rounded-full"></div>
                    <span className="font-bold text-lg text-alfresco-green">
                      {stats?.completedToday || 0}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}