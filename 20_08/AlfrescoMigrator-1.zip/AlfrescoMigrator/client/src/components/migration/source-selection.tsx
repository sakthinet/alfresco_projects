import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { ArrowLeft, ArrowRight, FileCode, Table, FileSpreadsheet, Database, Braces, Folder, CheckCircle, X } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { SourceType } from "@shared/schema";

interface SourceSelectionProps {
  onNext: () => void;
  onPrevious: () => void;
  onJobCreated: (jobId: number) => void;
  currentJobId: number | null;
}

interface SourceTypeConfig {
  id: SourceType;
  name: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  feature: string;
}

interface CSVConfig {
  delimiter: string;
  encoding: string;
  hasHeaders: boolean;
  skipEmptyRows: boolean;
  trimWhitespace: boolean;
}

export function SourceSelection({ onNext, onPrevious, onJobCreated, currentJobId }: SourceSelectionProps) {
  const [selectedSource, setSelectedSource] = useState<SourceType>("csv");
  const [csvConfig, setCsvConfig] = useState<CSVConfig>({
    delimiter: ",",
    encoding: "utf-8",
    hasHeaders: true,
    skipEmptyRows: false,
    trimWhitespace: false,
  });
  const [showConfig, setShowConfig] = useState(true);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const sourceTypes: SourceTypeConfig[] = [
    {
      id: "xml",
      name: "XML Files",
      description: "Import structured XML documents with metadata and content hierarchy.",
      icon: <FileCode className="w-6 h-6 text-orange-600" />,
      color: "bg-orange-100",
      feature: "Supports nested structures",
    },
    {
      id: "csv",
      name: "CSV Files",
      description: "Import tabular data from CSV files with column mapping support.",
      icon: <Table className="w-6 h-6 text-green-600" />,
      color: "bg-green-100",
      feature: "High performance",
    },
    {
      id: "xlsx",
      name: "Excel Files",
      description: "Import Excel workbooks with multiple sheets and complex formatting.",
      icon: <FileSpreadsheet className="w-6 h-6 text-blue-600" />,
      color: "bg-blue-100",
      feature: "Multi-sheet support",
    },
    {
      id: "database",
      name: "Database",
      description: "Connect to SQL databases for direct data migration with queries.",
      icon: <Database className="w-6 h-6 text-purple-600" />,
      color: "bg-purple-100",
      feature: "Real-time connection",
    },
    {
      id: "json",
      name: "JSON Files",
      description: "Import JSON documents with nested objects and arrays.",
      icon: <Braces className="w-6 h-6 text-yellow-600" />,
      color: "bg-yellow-100",
      feature: "Schema validation",
    },
    {
      id: "filesystem",
      name: "File System",
      description: "Bulk import files and folders from local or network file systems.",
      icon: <Folder className="w-6 h-6 text-slate-600" />,
      color: "bg-slate-100",
      feature: "Preserves structure",
    },
  ];

  const createJobMutation = useMutation({
    mutationFn: async (data: { name: string; sourceType: SourceType; configuration: any }) => {
      const response = await apiRequest("POST", "/api/migration-jobs", data);
      return response.json();
    },
    onSuccess: (data) => {
      onJobCreated(data.id);
      toast({
        title: "Success",
        description: "Migration job created successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create migration job",
        variant: "destructive",
      });
    },
  });

  const handleSaveConfig = async () => {
    if (!currentJobId) {
      // Create new job
      const jobData = {
        name: `${selectedSource.toUpperCase()} Migration - ${new Date().toLocaleDateString()}`,
        sourceType: selectedSource,
        configuration: selectedSource === "csv" ? csvConfig : {},
        status: "pending" as const,
      };

      createJobMutation.mutate(jobData);
    } else {
      // Update existing job
      try {
        await apiRequest("PATCH", `/api/migration-jobs/${currentJobId}`, {
          sourceType: selectedSource,
          configuration: selectedSource === "csv" ? csvConfig : {},
        });
        
        toast({
          title: "Success",
          description: "Configuration saved successfully",
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to save configuration",
          variant: "destructive",
        });
      }
    }
  };

  const handleContinue = () => {
    if (!currentJobId) {
      handleSaveConfig();
    } else {
      onNext();
    }
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Select Data Source</h1>
        <p className="text-lg text-slate-600">
          Choose the type of data source you want to migrate to Alfresco ECM repository.
        </p>
      </div>

      {/* Source Type Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {sourceTypes.map((source) => (
          <Card
            key={source.id}
            className={`cursor-pointer transition-all hover:shadow-lg ${
              selectedSource === source.id
                ? "border-2 border-primary shadow-lg"
                : "border border-slate-200 hover:border-primary"
            }`}
            onClick={() => {
              setSelectedSource(source.id);
              setShowConfig(source.id === "csv");
            }}
          >
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 ${source.color} rounded-lg flex items-center justify-center`}>
                  {source.icon}
                </div>
                <div className={`w-6 h-6 rounded-full ${
                  selectedSource === source.id
                    ? "bg-primary flex items-center justify-center"
                    : "border-2 border-slate-300"
                }`}>
                  {selectedSource === source.id && (
                    <CheckCircle className="w-4 h-4 text-white" />
                  )}
                </div>
              </div>
              <h3 className="text-lg font-semibold text-slate-900 mb-2">{source.name}</h3>
              <p className="text-sm text-slate-600 mb-4">{source.description}</p>
              <div className="flex items-center text-xs text-slate-500">
                <CheckCircle className="w-4 h-4 mr-1 text-success" />
                <span>{source.feature}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Configuration Panel */}
      {showConfig && selectedSource === "csv" && (
        <Card className="mb-8">
          <CardContent className="p-8">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <Table className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold text-slate-900">CSV Configuration</h2>
                  <p className="text-sm text-slate-600">Configure settings for CSV file processing</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setShowConfig(false)}>
                <X className="w-5 h-5" />
              </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* File Settings */}
              <div className="space-y-6">
                <h3 className="text-lg font-medium text-slate-900">File Settings</h3>
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="delimiter">Delimiter</Label>
                    <Select value={csvConfig.delimiter} onValueChange={(value) => 
                      setCsvConfig(prev => ({ ...prev, delimiter: value }))
                    }>
                      <SelectTrigger>
                        <SelectValue placeholder="Select delimiter" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value=",">Comma (,)</SelectItem>
                        <SelectItem value=";">Semicolon (;)</SelectItem>
                        <SelectItem value="\t">Tab</SelectItem>
                        <SelectItem value="|">Pipe (|)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="encoding">File Encoding</Label>
                    <Select value={csvConfig.encoding} onValueChange={(value) => 
                      setCsvConfig(prev => ({ ...prev, encoding: value }))
                    }>
                      <SelectTrigger>
                        <SelectValue placeholder="Select encoding" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="utf-8">UTF-8</SelectItem>
                        <SelectItem value="utf-16">UTF-16</SelectItem>
                        <SelectItem value="ascii">ASCII</SelectItem>
                        <SelectItem value="iso-8859-1">ISO-8859-1</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-slate-700 mb-3 block">Processing Options</Label>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="hasHeaders"
                          checked={csvConfig.hasHeaders}
                          onCheckedChange={(checked) => 
                            setCsvConfig(prev => ({ ...prev, hasHeaders: checked as boolean }))
                          }
                        />
                        <Label htmlFor="hasHeaders">First row contains headers</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="skipEmptyRows"
                          checked={csvConfig.skipEmptyRows}
                          onCheckedChange={(checked) => 
                            setCsvConfig(prev => ({ ...prev, skipEmptyRows: checked as boolean }))
                          }
                        />
                        <Label htmlFor="skipEmptyRows">Skip empty rows</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="trimWhitespace"
                          checked={csvConfig.trimWhitespace}
                          onCheckedChange={(checked) => 
                            setCsvConfig(prev => ({ ...prev, trimWhitespace: checked as boolean }))
                          }
                        />
                        <Label htmlFor="trimWhitespace">Trim whitespace</Label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Preview */}
              <div className="space-y-6">
                <h3 className="text-lg font-medium text-slate-900">Data Preview</h3>
                
                <Card>
                  <div className="bg-slate-50 px-4 py-2 border-b border-slate-200 rounded-t-lg">
                    <span className="text-sm font-medium text-slate-700">Sample Data (First 5 rows)</span>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200">
                      <thead className="bg-slate-50">
                        <tr>
                          <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                            Document ID
                          </th>
                          <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                            Title
                          </th>
                          <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                            Author
                          </th>
                          <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                            Created Date
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-slate-200">
                        <tr>
                          <td className="px-4 py-2 text-sm text-slate-900">DOC001</td>
                          <td className="px-4 py-2 text-sm text-slate-900">Annual Report 2023</td>
                          <td className="px-4 py-2 text-sm text-slate-900">John Smith</td>
                          <td className="px-4 py-2 text-sm text-slate-900">2023-01-15</td>
                        </tr>
                        <tr>
                          <td className="px-4 py-2 text-sm text-slate-900">DOC002</td>
                          <td className="px-4 py-2 text-sm text-slate-900">Policy Document</td>
                          <td className="px-4 py-2 text-sm text-slate-900">Jane Doe</td>
                          <td className="px-4 py-2 text-sm text-slate-900">2023-02-20</td>
                        </tr>
                        <tr>
                          <td className="px-4 py-2 text-sm text-slate-900">DOC003</td>
                          <td className="px-4 py-2 text-sm text-slate-900">Meeting Minutes</td>
                          <td className="px-4 py-2 text-sm text-slate-900">Mike Johnson</td>
                          <td className="px-4 py-2 text-sm text-slate-900">2023-03-10</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </Card>

                {/* Validation Summary */}
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
                    <span className="text-sm font-medium text-green-800">Data validation passed</span>
                  </div>
                  <div className="mt-2 text-sm text-green-700">
                    <ul className="list-disc list-inside space-y-1">
                      <li>147 rows detected</li>
                      <li>4 columns identified</li>
                      <li>No missing required fields</li>
                      <li>Date formats are valid</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Action Buttons */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={onPrevious}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Previous Step
        </Button>
        <div className="flex items-center space-x-3">
          <Button variant="outline" onClick={handleSaveConfig} disabled={createJobMutation.isPending}>
            Save Configuration
          </Button>
          <Button onClick={handleContinue} disabled={createJobMutation.isPending}>
            Continue to Upload
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}
