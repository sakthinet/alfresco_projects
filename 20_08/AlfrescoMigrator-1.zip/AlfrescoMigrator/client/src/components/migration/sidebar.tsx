import React from "react";
import { Button } from "@/components/ui/button";
import { Database } from "lucide-react";
import { cn } from "@/lib/utils";
import type { MigrationStep } from "@/pages/migration";

interface MigrationSidebarProps {
  currentStep: MigrationStep;
  onStepChange: (step: MigrationStep) => void;
  stats?: {
    totalMigrations: number;
    activeJobs: number;
    completedToday: number;
  };
}

export function MigrationSidebar({ currentStep, onStepChange, stats }: MigrationSidebarProps) {
  const steps = [
    { id: "overview" as const, label: "Overview", number: 1 },
    { id: "source-selection" as const, label: "Source Selection", number: 2 },
    { id: "file-upload" as const, label: "File Upload", number: 3 },
    { id: "data-mapping" as const, label: "Data Mapping", number: 4 },
    { id: "alfresco-config" as const, label: "Alfresco Config", number: 5 },
    { id: "migration" as const, label: "Migration", number: 6 },
  ];

  return (
    <div className="w-80 bg-white shadow-lg border-r border-slate-200 flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-slate-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Database className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-semibold text-slate-900">Alfresco Migration</h1>
            <p className="text-sm text-slate-500">Data Migration Utility</p>
          </div>
        </div>
      </div>

      {/* Step Navigation */}
      <div className="flex-1 p-6">
        <h2 className="text-sm font-medium text-slate-900 mb-4">Migration Steps</h2>
        <nav className="space-y-2">
          {steps.map((step) => (
            <Button
              key={step.id}
              variant="ghost"
              className={cn(
                "w-full justify-start p-3 h-auto",
                currentStep === step.id
                  ? "bg-primary text-white hover:bg-primary/90"
                  : "text-slate-600 hover:bg-slate-50"
              )}
              onClick={() => onStepChange(step.id)}
            >
              <div className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center mr-3",
                currentStep === step.id
                  ? "bg-white/20"
                  : "bg-slate-100"
              )}>
                <span className={cn(
                  "text-sm font-medium",
                  currentStep === step.id ? "text-white" : "text-slate-900"
                )}>
                  {step.number}
                </span>
              </div>
              <span className="font-medium">{step.label}</span>
            </Button>
          ))}
        </nav>
      </div>

      {/* Quick Stats */}
      <div className="p-6 border-t border-slate-200">
        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-slate-600">Total Migrations</span>
            <span className="font-medium text-slate-900">
              {stats?.totalMigrations || 0}
            </span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-slate-600">Active Jobs</span>
            <span className="font-medium text-warning">
              {stats?.activeJobs || 0}
            </span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-slate-600">Completed Today</span>
            <span className="font-medium text-success">
              {stats?.completedToday || 0}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
