import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, Database, FileText, Settings, Zap } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface OverviewProps {
  onNext: () => void;
}

export function Overview({ onNext }: OverviewProps) {
  const { data: stats } = useQuery({
    queryKey: ["/api/migration-stats"],
  });

  const features = [
    {
      icon: <Database className="w-6 h-6 text-blue-600" />,
      title: "Multiple Data Sources",
      description: "Support for CSV, Excel, XML, JSON, Database, and File System sources with flexible configuration options.",
    },
    {
      icon: <FileText className="w-6 h-6 text-green-600" />,
      title: "Smart Data Mapping",
      description: "Intelligent field mapping with preview and validation to ensure data integrity during migration.",
    },
    {
      icon: <Settings className="w-6 h-6 text-purple-600" />,
      title: "Alfresco Integration",
      description: "Seamless connection to Alfresco ECM with configurable repository settings and folder structures.",
    },
    {
      icon: <Zap className="w-6 h-6 text-orange-600" />,
      title: "Real-time Monitoring",
      description: "Live progress tracking, error handling, and detailed migration logs for complete visibility.",
    },
  ];

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Migration Overview</h1>
        <p className="text-lg text-slate-600">
          Welcome to the Alfresco Migration Utility. This tool helps you migrate data from various sources to your Alfresco ECM repository.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Total Migrations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">
              {stats?.totalMigrations || 0}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Active Jobs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-warning">
              {stats?.activeJobs || 0}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Completed Today</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">
              {stats?.completedToday || 0}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Features */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {features.map((feature, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  {feature.icon}
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-slate-600">
                    {feature.description}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Migration Process */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Migration Process</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="text-sm font-medium text-blue-600">1</span>
              </div>
              <div>
                <h4 className="font-medium text-slate-900">Select Data Source</h4>
                <p className="text-sm text-slate-600">Choose your data source type and configure import settings</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="text-sm font-medium text-blue-600">2</span>
              </div>
              <div>
                <h4 className="font-medium text-slate-900">Upload Files</h4>
                <p className="text-sm text-slate-600">Upload your data files with drag-and-drop support</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="text-sm font-medium text-blue-600">3</span>
              </div>
              <div>
                <h4 className="font-medium text-slate-900">Map Data Fields</h4>
                <p className="text-sm text-slate-600">Map source fields to Alfresco properties and validate data</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="text-sm font-medium text-blue-600">4</span>
              </div>
              <div>
                <h4 className="font-medium text-slate-900">Configure Alfresco</h4>
                <p className="text-sm text-slate-600">Set up connection to your Alfresco repository</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="text-sm font-medium text-blue-600">5</span>
              </div>
              <div>
                <h4 className="font-medium text-slate-900">Run Migration</h4>
                <p className="text-sm text-slate-600">Execute the migration with real-time progress monitoring</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Button */}
      <div className="flex justify-end">
        <Button onClick={onNext} size="lg">
          Start Migration
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}
