import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, Play, Pause, Square, AlertCircle, CheckCircle, Clock, FileText } from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { MigrationJob, MigrationLog } from "@shared/schema";

interface MigrationRunnerProps {
  onPrevious: () => void;
  jobId: number | null;
}

export function MigrationRunner({ onPrevious, jobId }: MigrationRunnerProps) {
  const [migrationStatus, setMigrationStatus] = useState<"pending" | "running" | "paused" | "completed" | "failed">("pending");
  const [progress, setProgress] = useState(0);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [endTime, setEndTime] = useState<Date | null>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: job } = useQuery({
    queryKey: ["/api/migration-jobs", jobId],
    enabled: !!jobId,
    refetchInterval: migrationStatus === "running" ? 1000 : false,
  });

  const { data: logs } = useQuery({
    queryKey: ["/api/migration-jobs", jobId, "logs"],
    enabled: !!jobId,
    refetchInterval: migrationStatus === "running" ? 2000 : false,
  });

  const startMigrationMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/migration-jobs/${jobId}/start`);
      return response.json();
    },
    onSuccess: () => {
      setMigrationStatus("running");
      setStartTime(new Date());
      setProgress(0);
      toast({
        title: "Migration Started",
        description: "The migration process has begun",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to start migration",
        variant: "destructive",
      });
    },
  });

  // Simulate migration progress
  useEffect(() => {
    if (migrationStatus === "running") {
      const interval = setInterval(() => {
        setProgress(prev => {
          const newProgress = Math.min(prev + Math.random() * 5, 100);
          if (newProgress >= 100) {
            setMigrationStatus("completed");
            setEndTime(new Date());
            clearInterval(interval);
            toast({
              title: "Migration Completed",
              description: "All data has been successfully migrated",
            });
          }
          return newProgress;
        });
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [migrationStatus, toast]);

  const formatDuration = (start: Date, end?: Date) => {
    const endTime = end || new Date();
    const diff = endTime.getTime() - start.getTime();
    const minutes = Math.floor(diff / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "running":
        return "text-blue-600";
      case "completed":
        return "text-success";
      case "failed":
        return "text-error";
      case "paused":
        return "text-warning";
      default:
        return "text-slate-600";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "running":
        return <Clock className="w-5 h-5 text-blue-600" />;
      case "completed":
        return <CheckCircle className="w-5 h-5 text-success" />;
      case "failed":
        return <AlertCircle className="w-5 h-5 text-error" />;
      case "paused":
        return <Pause className="w-5 h-5 text-warning" />;
      default:
        return <Clock className="w-5 h-5 text-slate-600" />;
    }
  };

  if (!jobId) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="w-12 h-12 text-orange-500 mx-auto mb-4" />
        <h2 className="text-xl font-semibold text-slate-900 mb-2">No Migration Job Selected</h2>
        <p className="text-slate-600 mb-4">Please go back and create a migration job first.</p>
        <Button onClick={onPrevious}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Go Back
        </Button>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Migration Execution</h1>
        <p className="text-lg text-slate-600">
          Monitor and control the migration process. Track progress and view detailed logs in real-time.
        </p>
      </div>

      {/* Migration Status */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Migration Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Status and Progress */}
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {getStatusIcon(migrationStatus)}
                <div>
                  <h3 className={`text-lg font-semibold ${getStatusColor(migrationStatus)}`}>
                    {migrationStatus.charAt(0).toUpperCase() + migrationStatus.slice(1)}
                  </h3>
                  <p className="text-sm text-slate-600">
                    {job?.name || "Migration Job"}
                  </p>
                </div>
              </div>
              
              <div className="text-right">
                <div className="text-2xl font-bold text-slate-900">
                  {Math.round(progress)}%
                </div>
                <div className="text-sm text-slate-600">
                  {startTime && (
                    <>
                      Duration: {formatDuration(startTime, endTime)}
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="space-y-2">
              <Progress value={progress} className="h-3" />
              <div className="flex justify-between text-sm text-slate-600">
                <span>0 records</span>
                <span>{job?.totalRecords || 0} records</span>
              </div>
            </div>

            {/* Control Buttons */}
            <div className="flex items-center space-x-3">
              {migrationStatus === "pending" && (
                <Button onClick={() => startMigrationMutation.mutate()} disabled={startMigrationMutation.isPending}>
                  <Play className="w-4 h-4 mr-2" />
                  Start Migration
                </Button>
              )}
              
              {migrationStatus === "running" && (
                <>
                  <Button variant="outline" onClick={() => setMigrationStatus("paused")}>
                    <Pause className="w-4 h-4 mr-2" />
                    Pause
                  </Button>
                  <Button variant="outline" onClick={() => setMigrationStatus("failed")}>
                    <Square className="w-4 h-4 mr-2" />
                    Stop
                  </Button>
                </>
              )}
              
              {migrationStatus === "paused" && (
                <Button onClick={() => setMigrationStatus("running")}>
                  <Play className="w-4 h-4 mr-2" />
                  Resume
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Total Records</p>
                <p className="text-2xl font-bold text-slate-900">{job?.totalRecords || 0}</p>
              </div>
              <FileText className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Processed</p>
                <p className="text-2xl font-bold text-slate-900">{Math.round((progress / 100) * (job?.totalRecords || 0))}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-success" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Remaining</p>
                <p className="text-2xl font-bold text-slate-900">{(job?.totalRecords || 0) - Math.round((progress / 100) * (job?.totalRecords || 0))}</p>
              </div>
              <Clock className="w-8 h-8 text-warning" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Errors</p>
                <p className="text-2xl font-bold text-slate-900">{job?.errorCount || 0}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-error" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Migration Logs */}
      <Card>
        <CardHeader>
          <CardTitle>Migration Logs</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {logs && logs.length > 0 ? (
              logs.map((log: MigrationLog) => (
                <div key={log.id} className="flex items-start space-x-3 p-3 bg-slate-50 rounded-lg">
                  <div className={`w-2 h-2 rounded-full mt-2 ${
                    log.level === "error" ? "bg-error" : 
                    log.level === "warning" ? "bg-warning" : "bg-success"
                  }`} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-slate-900">
                        {log.message}
                      </p>
                      <span className="text-xs text-slate-500">
                        {new Date(log.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    {log.details && (
                      <p className="text-xs text-slate-600 mt-1">
                        {JSON.stringify(log.details)}
                      </p>
                    )}
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <p className="text-slate-500">No logs available</p>
                <p className="text-sm text-slate-400">Logs will appear here once the migration starts</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex items-center justify-between mt-8">
        <Button variant="ghost" onClick={onPrevious}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Previous Step
        </Button>
        
        {migrationStatus === "completed" && (
          <Button onClick={() => window.location.reload()}>
            Start New Migration
          </Button>
        )}
      </div>
    </div>
  );
}
