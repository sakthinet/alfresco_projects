import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowLeft, ArrowRight, AlertCircle, CheckCircle, TestTube } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { AlfrescoConfig } from "@shared/schema";

interface AlfrescoConfigProps {
  onNext: () => void;
  onPrevious: () => void;
  jobId: number | null;
}

const alfrescoConfigSchema = z.object({
  serverUrl: z.string().url("Please enter a valid server URL"),
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
  repositoryId: z.string().min(1, "Repository ID is required"),
  targetPath: z.string().min(1, "Target path is required"),
  createFolderStructure: z.boolean().default(true),
});

type AlfrescoConfigForm = z.infer<typeof alfrescoConfigSchema>;

export function AlfrescoConfig({ onNext, onPrevious, jobId }: AlfrescoConfigProps) {
  const [connectionStatus, setConnectionStatus] = useState<"idle" | "testing" | "success" | "error">("idle");
  const [connectionError, setConnectionError] = useState<string>("");

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<AlfrescoConfigForm>({
    resolver: zodResolver(alfrescoConfigSchema),
    defaultValues: {
      serverUrl: "http://localhost:8080/alfresco",
      username: "",
      password: "",
      repositoryId: "-default-",
      targetPath: "/Company Home/Migration",
      createFolderStructure: true,
    },
  });

  const { data: existingConfig, isLoading } = useQuery({
    queryKey: ["/api/migration-jobs", jobId, "alfresco-config"],
    enabled: !!jobId,
    onSuccess: (data: AlfrescoConfig) => {
      if (data) {
        form.reset({
          serverUrl: data.serverUrl,
          username: data.username,
          password: data.password,
          repositoryId: data.repositoryId,
          targetPath: data.targetPath,
          createFolderStructure: data.createFolderStructure,
        });
        setConnectionStatus("success");
      }
    },
    onError: () => {
      // Config doesn't exist yet, which is fine
    },
  });

  const saveConfigMutation = useMutation({
    mutationFn: async (data: AlfrescoConfigForm) => {
      const response = await apiRequest("POST", `/api/migration-jobs/${jobId}/alfresco-config`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/migration-jobs", jobId, "alfresco-config"] });
      toast({
        title: "Success",
        description: "Alfresco configuration saved successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save Alfresco configuration",
        variant: "destructive",
      });
    },
  });

  const testConnection = async () => {
    const values = form.getValues();
    setConnectionStatus("testing");
    setConnectionError("");

    try {
      // Simulate connection test
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // In a real implementation, this would make an actual API call to test the connection
      if (values.serverUrl && values.username && values.password) {
        setConnectionStatus("success");
        toast({
          title: "Success",
          description: "Connection to Alfresco server established successfully",
        });
      } else {
        throw new Error("Missing required connection parameters");
      }
    } catch (error) {
      setConnectionStatus("error");
      setConnectionError("Failed to connect to Alfresco server. Please check your credentials and server URL.");
      toast({
        title: "Connection Failed",
        description: "Could not connect to Alfresco server",
        variant: "destructive",
      });
    }
  };

  const onSubmit = (data: AlfrescoConfigForm) => {
    if (!jobId) return;
    saveConfigMutation.mutate(data);
  };

  const handleContinue = () => {
    form.handleSubmit((data) => {
      onSubmit(data);
      // Wait for save to complete, then proceed
      setTimeout(() => {
        if (!saveConfigMutation.isError) {
          onNext();
        }
      }, 1000);
    })();
  };

  if (!jobId) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="w-12 h-12 text-orange-500 mx-auto mb-4" />
        <h2 className="text-xl font-semibold text-slate-900 mb-2">No Migration Job Selected</h2>
        <p className="text-slate-600 mb-4">Please go back and create a migration job first.</p>
        <Button onClick={onPrevious}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Go Back
        </Button>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Alfresco Configuration</h1>
        <p className="text-lg text-slate-600">
          Configure the connection to your Alfresco ECM repository and specify the target location for migrated content.
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          {/* Connection Settings */}
          <Card>
            <CardHeader>
              <CardTitle>Connection Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <FormField
                control={form.control}
                name="serverUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Server URL</FormLabel>
                    <FormControl>
                      <Input placeholder="http://localhost:8080/alfresco" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input placeholder="admin" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="********" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="repositoryId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Repository ID</FormLabel>
                    <FormControl>
                      <Input placeholder="-default-" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Connection Test */}
              <div className="flex items-center space-x-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={testConnection}
                  disabled={connectionStatus === "testing"}
                >
                  <TestTube className="w-4 h-4 mr-2" />
                  {connectionStatus === "testing" ? "Testing..." : "Test Connection"}
                </Button>

                {connectionStatus === "success" && (
                  <div className="flex items-center text-success">
                    <CheckCircle className="w-4 h-4 mr-2" />
                    <span className="text-sm">Connection successful</span>
                  </div>
                )}

                {connectionStatus === "error" && (
                  <div className="flex items-center text-error">
                    <AlertCircle className="w-4 h-4 mr-2" />
                    <span className="text-sm">Connection failed</span>
                  </div>
                )}
              </div>

              {connectionError && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <div className="flex items-center">
                    <AlertCircle className="w-5 h-5 text-red-600 mr-2" />
                    <span className="text-sm font-medium text-red-800">Connection Error</span>
                  </div>
                  <p className="mt-1 text-sm text-red-700">{connectionError}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Migration Settings */}
          <Card>
            <CardHeader>
              <CardTitle>Migration Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <FormField
                control={form.control}
                name="targetPath"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Target Path</FormLabel>
                    <FormControl>
                      <Input placeholder="/Company Home/Migration" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="createFolderStructure"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Create folder structure</FormLabel>
                      <p className="text-sm text-muted-foreground">
                        Automatically create folders based on the source data structure
                      </p>
                    </div>
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Configuration Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Configuration Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-slate-50 rounded-lg p-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium text-slate-700">Server:</span>
                    <span className="ml-2 text-slate-900">{form.watch("serverUrl") || "Not configured"}</span>
                  </div>
                  <div>
                    <span className="font-medium text-slate-700">Username:</span>
                    <span className="ml-2 text-slate-900">{form.watch("username") || "Not configured"}</span>
                  </div>
                  <div>
                    <span className="font-medium text-slate-700">Repository:</span>
                    <span className="ml-2 text-slate-900">{form.watch("repositoryId") || "Not configured"}</span>
                  </div>
                  <div>
                    <span className="font-medium text-slate-700">Target Path:</span>
                    <span className="ml-2 text-slate-900">{form.watch("targetPath") || "Not configured"}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </form>
      </Form>

      {/* Action Buttons */}
      <div className="flex items-center justify-between mt-8">
        <Button variant="ghost" onClick={onPrevious}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Previous Step
        </Button>
        <div className="flex items-center space-x-3">
          <Button variant="outline" onClick={form.handleSubmit(onSubmit)} disabled={saveConfigMutation.isPending}>
            Save Configuration
          </Button>
          <Button onClick={handleContinue} disabled={connectionStatus !== "success" || saveConfigMutation.isPending}>
            Continue to Migration
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}
