import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowLeft, ArrowRight, Plus, Trash2, AlertCircle, CheckCircle } from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { FieldMapping } from "@shared/schema";

interface DataMappingProps {
  onNext: () => void;
  onPrevious: () => void;
  jobId: number | null;
}

interface MappingRow {
  id?: number;
  sourceField: string;
  targetField: string;
  transformation: string;
  isRequired: boolean;
}

export function DataMapping({ onNext, onPrevious, jobId }: DataMappingProps) {
  const [mappings, setMappings] = useState<MappingRow[]>([
    { sourceField: "Document ID", targetField: "cm:name", transformation: "", isRequired: true },
    { sourceField: "Title", targetField: "cm:title", transformation: "", isRequired: true },
    { sourceField: "Author", targetField: "cm:author", transformation: "", isRequired: false },
    { sourceField: "Created Date", targetField: "cm:created", transformation: "date", isRequired: false },
  ]);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: existingMappings, isLoading } = useQuery({
    queryKey: ["/api/migration-jobs", jobId, "mappings"],
    enabled: !!jobId,
    onSuccess: (data) => {
      if (data && data.length > 0) {
        setMappings(data.map((mapping: FieldMapping) => ({
          id: mapping.id,
          sourceField: mapping.sourceField,
          targetField: mapping.targetField,
          transformation: mapping.transformation || "",
          isRequired: mapping.isRequired,
        })));
      }
    },
  });

  const saveMappingsMutation = useMutation({
    mutationFn: async (mappingsData: MappingRow[]) => {
      const promises = mappingsData.map(mapping => {
        if (mapping.id) {
          return apiRequest("PATCH", `/api/migration-jobs/${jobId}/mappings/${mapping.id}`, mapping);
        } else {
          return apiRequest("POST", `/api/migration-jobs/${jobId}/mappings`, mapping);
        }
      });
      
      await Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/migration-jobs", jobId, "mappings"] });
      toast({
        title: "Success",
        description: "Field mappings saved successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save field mappings",
        variant: "destructive",
      });
    },
  });

  const sourceFields = [
    "Document ID",
    "Title", 
    "Author",
    "Created Date",
    "Modified Date",
    "File Path",
    "File Size",
    "Content Type",
    "Description",
    "Category",
    "Tags",
    "Department",
    "Status",
  ];

  const targetFields = [
    "cm:name",
    "cm:title",
    "cm:description", 
    "cm:author",
    "cm:created",
    "cm:modified",
    "cm:content",
    "cm:contentEncoding",
    "cm:mimeType",
    "cm:sizeInBytes",
    "sys:node-uuid",
    "sys:node-dbid",
    "sys:store-protocol",
    "sys:store-identifier",
    "sys:path",
  ];

  const transformations = [
    { value: "", label: "None" },
    { value: "uppercase", label: "Uppercase" },
    { value: "lowercase", label: "Lowercase" },
    { value: "date", label: "Date Format" },
    { value: "number", label: "Number Format" },
    { value: "trim", label: "Trim Whitespace" },
  ];

  const addMapping = () => {
    setMappings(prev => [...prev, {
      sourceField: "",
      targetField: "",
      transformation: "",
      isRequired: false,
    }]);
  };

  const removeMapping = (index: number) => {
    setMappings(prev => prev.filter((_, i) => i !== index));
  };

  const updateMapping = (index: number, field: keyof MappingRow, value: any) => {
    setMappings(prev => prev.map((mapping, i) => 
      i === index ? { ...mapping, [field]: value } : mapping
    ));
  };

  const handleSave = () => {
    if (!jobId) return;
    saveMappingsMutation.mutate(mappings);
  };

  const handleContinue = () => {
    if (!jobId) return;
    handleSave();
    // Wait for save to complete, then proceed
    setTimeout(() => {
      if (!saveMappingsMutation.isError) {
        onNext();
      }
    }, 1000);
  };

  const isValid = mappings.every(m => m.sourceField && m.targetField);

  if (!jobId) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="w-12 h-12 text-orange-500 mx-auto mb-4" />
        <h2 className="text-xl font-semibold text-slate-900 mb-2">No Migration Job Selected</h2>
        <p className="text-slate-600 mb-4">Please go back and create a migration job first.</p>
        <Button onClick={onPrevious}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Go Back
        </Button>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Data Field Mapping</h1>
        <p className="text-lg text-slate-600">
          Map your source data fields to Alfresco content model properties. Configure transformations as needed.
        </p>
      </div>

      {/* Mapping Table */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Field Mappings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Header */}
            <div className="grid grid-cols-12 gap-4 pb-2 border-b border-slate-200">
              <div className="col-span-3">
                <Label className="text-sm font-medium text-slate-700">Source Field</Label>
              </div>
              <div className="col-span-3">
                <Label className="text-sm font-medium text-slate-700">Target Field</Label>
              </div>
              <div className="col-span-2">
                <Label className="text-sm font-medium text-slate-700">Transformation</Label>
              </div>
              <div className="col-span-2">
                <Label className="text-sm font-medium text-slate-700">Required</Label>
              </div>
              <div className="col-span-2">
                <Label className="text-sm font-medium text-slate-700">Actions</Label>
              </div>
            </div>

            {/* Mapping Rows */}
            {mappings.map((mapping, index) => (
              <div key={index} className="grid grid-cols-12 gap-4 items-center">
                <div className="col-span-3">
                  <Select
                    value={mapping.sourceField}
                    onValueChange={(value) => updateMapping(index, "sourceField", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select source field" />
                    </SelectTrigger>
                    <SelectContent>
                      {sourceFields.map(field => (
                        <SelectItem key={field} value={field}>{field}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="col-span-3">
                  <Select
                    value={mapping.targetField}
                    onValueChange={(value) => updateMapping(index, "targetField", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select target field" />
                    </SelectTrigger>
                    <SelectContent>
                      {targetFields.map(field => (
                        <SelectItem key={field} value={field}>{field}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="col-span-2">
                  <Select
                    value={mapping.transformation}
                    onValueChange={(value) => updateMapping(index, "transformation", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Transformation" />
                    </SelectTrigger>
                    <SelectContent>
                      {transformations.map(transform => (
                        <SelectItem key={transform.value} value={transform.value}>
                          {transform.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="col-span-2">
                  <Checkbox
                    checked={mapping.isRequired}
                    onCheckedChange={(checked) => updateMapping(index, "isRequired", checked)}
                  />
                </div>
                
                <div className="col-span-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeMapping(index)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}

            {/* Add Mapping Button */}
            <Button variant="outline" onClick={addMapping} className="w-full">
              <Plus className="w-4 h-4 mr-2" />
              Add Field Mapping
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Validation Summary */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Mapping Validation</CardTitle>
        </CardHeader>
        <CardContent>
          <div className={`flex items-center p-4 rounded-lg ${
            isValid ? "bg-green-50 border border-green-200" : "bg-red-50 border border-red-200"
          }`}>
            {isValid ? (
              <>
                <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
                <div>
                  <span className="text-sm font-medium text-green-800">Mapping validation passed</span>
                  <div className="mt-1 text-sm text-green-700">
                    <ul className="list-disc list-inside space-y-1">
                      <li>{mappings.length} field mappings configured</li>
                      <li>{mappings.filter(m => m.isRequired).length} required fields mapped</li>
                      <li>{mappings.filter(m => m.transformation).length} transformations applied</li>
                    </ul>
                  </div>
                </div>
              </>
            ) : (
              <>
                <AlertCircle className="w-5 h-5 text-red-600 mr-2" />
                <div>
                  <span className="text-sm font-medium text-red-800">Mapping validation failed</span>
                  <p className="mt-1 text-sm text-red-700">
                    Please ensure all mappings have both source and target fields selected.
                  </p>
                </div>
              </>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={onPrevious}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Previous Step
        </Button>
        <div className="flex items-center space-x-3">
          <Button variant="outline" onClick={handleSave} disabled={saveMappingsMutation.isPending}>
            Save Mappings
          </Button>
          <Button onClick={handleContinue} disabled={!isValid || saveMappingsMutation.isPending}>
            Continue to Alfresco Config
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}
