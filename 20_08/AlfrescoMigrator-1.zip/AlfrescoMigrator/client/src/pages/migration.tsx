import React, { useState } from "react";
import { Overview } from "@/components/migration/overview";
import { SourceSelection } from "@/components/migration/source-selection";
import { FileUpload } from "@/components/migration/file-upload";
import { DataMapping } from "@/components/migration/data-mapping";
import { AlfrescoConfig } from "@/components/migration/alfresco-config";
import { MigrationRunner } from "@/components/migration/migration-runner";
import { HamburgerMenu } from "@/components/hamburger-menu";
import { UserProfileDropdown } from "@/components/user-profile-dropdown";
import { AuthDialog } from "@/components/auth-dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { History, Play, Database, Moon, Sun, LogIn } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useTheme } from "@/components/theme-provider";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import type { MigrationJob } from "@shared/schema";

export type MigrationStep = 
  | "overview" 
  | "source-selection" 
  | "file-upload" 
  | "data-mapping" 
  | "alfresco-config" 
  | "migration";

export default function Migration() {
  const [currentTab, setCurrentTab] = useState<MigrationStep>("overview");
  const [currentJobId, setCurrentJobId] = useState<number | null>(null);
  const [user, setUser] = useState<{ name: string; email: string; role: string } | null>(null);
  const [showAuthDialog, setShowAuthDialog] = useState(false);
  const { theme, setTheme } = useTheme();
  const { toast } = useToast();

  const { data: stats } = useQuery<{
    totalMigrations: number;
    activeJobs: number;
    completedToday: number;
  }>({
    queryKey: ["/api/migration-stats"],
    refetchInterval: 30000,
  });

  const { data: jobs } = useQuery<MigrationJob[]>({
    queryKey: ["/api/migration-jobs"],
    refetchInterval: 5000,
  });

  const getCurrentTabLabel = () => {
    switch (currentTab) {
      case "overview": return "Migration Overview";
      case "source-selection": return "Source Selection";
      case "file-upload": return "File Upload";
      case "data-mapping": return "Data Mapping";
      case "alfresco-config": return "Alfresco Configuration";
      case "migration": return "Migration Execution";
      default: return "Migration Overview";
    }
  };

  const handleNext = (nextTab: MigrationStep) => {
    setCurrentTab(nextTab);
  };

  const handlePrevious = (prevTab: MigrationStep) => {
    setCurrentTab(prevTab);
  };

  const handleLogin = () => {
    setShowAuthDialog(true);
  };

  const handleLogout = () => {
    setUser(null);
    toast({
      title: "Signed out",
      description: "You have been successfully signed out of your account.",
    });
  };

  const handleAuthSuccess = (userData: { name: string; email: string; role: string }) => {
    setUser(userData);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar */}
      <HamburgerMenu 
        currentTab={currentTab}
        onTabChange={(tab) => setCurrentTab(tab as MigrationStep)}
        stats={stats}
        user={user}
        onLogin={handleLogin}
        onLogout={handleLogout}
      />
      
      {/* Main Content - offset by sidebar width on desktop */}
      <div className="lg:ml-80">
        {/* Header */}
        <div className="bg-card border-b border-border px-4 lg:px-8 py-4 animate-fade-in">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-alfresco-blue rounded-lg flex items-center justify-center">
                  <Database className="w-6 h-6 text-white" />
                </div>
                <div className="hidden lg:block">
                  <h1 className="text-xl font-semibold text-foreground">Alfresco Migration Utility</h1>
                  <p className="text-sm text-muted-foreground">
                    {getCurrentTabLabel()} • Data Migration to ECM Repository
                  </p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                className="hidden lg:flex"
              >
                {theme === "dark" ? (
                  <Sun className="w-4 h-4" />
                ) : (
                  <Moon className="w-4 h-4" />
                )}
              </Button>
              <Button variant="ghost" size="sm" className="hidden lg:flex">
                <History className="w-4 h-4 mr-2" />
                History
              </Button>
              
              {user ? (
                <>
                  <Button 
                    size="sm" 
                    disabled={!currentJobId}
                    className="bg-alfresco-blue hover:bg-alfresco-blue/90 text-white animate-pulse-slow"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Start Migration
                  </Button>
                  <UserProfileDropdown user={user} onLogout={handleLogout} />
                </>
              ) : (
                <Button 
                  size="sm" 
                  className="bg-alfresco-blue hover:bg-alfresco-blue/90 text-white"
                  onClick={handleLogin}
                >
                  <LogIn className="w-4 h-4 mr-2" />
                  Sign In
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Main Content */}
        <Tabs value={currentTab} onValueChange={(value) => setCurrentTab(value as MigrationStep)}>
          <div className="hidden">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="source-selection">Source Selection</TabsTrigger>
              <TabsTrigger value="file-upload">File Upload</TabsTrigger>
              <TabsTrigger value="data-mapping">Data Mapping</TabsTrigger>
              <TabsTrigger value="alfresco-config">Alfresco Config</TabsTrigger>
              <TabsTrigger value="migration">Migration</TabsTrigger>
            </TabsList>
          </div>
          
          <div className="container mx-auto px-4 lg:px-8 py-8">
            <TabsContent value="overview" className="mt-0">
              <Overview onNext={() => handleNext("source-selection")} />
            </TabsContent>

            <TabsContent value="source-selection" className="mt-0">
              <SourceSelection 
                onNext={() => handleNext("file-upload")} 
                onPrevious={() => handlePrevious("overview")}
                onJobCreated={setCurrentJobId}
                currentJobId={currentJobId}
              />
            </TabsContent>

            <TabsContent value="file-upload" className="mt-0">
              <FileUpload 
                onNext={() => handleNext("data-mapping")} 
                onPrevious={() => handlePrevious("source-selection")}
                jobId={currentJobId}
              />
            </TabsContent>

            <TabsContent value="data-mapping" className="mt-0">
              <DataMapping 
                onNext={() => handleNext("alfresco-config")} 
                onPrevious={() => handlePrevious("file-upload")}
                jobId={currentJobId}
              />
            </TabsContent>

            <TabsContent value="alfresco-config" className="mt-0">
              <AlfrescoConfig 
                onNext={() => handleNext("migration")} 
                onPrevious={() => handlePrevious("data-mapping")}
                jobId={currentJobId}
              />
            </TabsContent>

            <TabsContent value="migration" className="mt-0">
              <MigrationRunner 
                onPrevious={() => handlePrevious("alfresco-config")}
                jobId={currentJobId}
              />
            </TabsContent>
          </div>
        </Tabs>
      </div>

      {/* Authentication Dialog */}
      <AuthDialog 
        open={showAuthDialog}
        onOpenChange={setShowAuthDialog}
        onAuthSuccess={handleAuthSuccess}
      />
    </div>
  );
}